/*
 * power.h
 */

#ifndef CORE_POWER_POWER_H_
#define CORE_POWER_POWER_H_

#include "../core.h"

class Power
{
protected:
	std::string name;
	int duration;
	int damageRange;

public:
	/*
	 * PRE: Receive range damage and duration of power on the board
	 * POS: Create an instance of power associated with the card
	 */
	Power(int duration, int damageRange);
	
	// Destructor
	virtual ~Power();
	
	/*
	 * PRE: ---------
	 * POS: Get the name power
	 */
	virtual std::string getPowerName();
	
	/*
	 * PRE: ---------
	 * POS: Get duration of the power
	 */
	unsigned int getDuration();
	
	
	/*
	 * PRE: ---------
	 * POS: Get damage range of the power
	 */
	int getDamageRange();
	
	/*
	 * PRE: Receives the name associated with power
	 * POS: Set the power name
	 */
	void setPowerName(std::string name);
	
	/*
	 * PRE: Receives the name associated with power
	 * POS: Set duration of the power
	 */
	void setDuration(unsigned int duration);
	
	/*
	 * PRE: Receive range damage from power
	 * POS: Set damage range of the power
	 */
	void setDamageRange(int damageRange);
	
	/*
	 * PRE: --------
	 * POS: Activate the power of the card and execute it on the board
	 */
	virtual void activatePower();
};

#endif /* CORE_POWER_POWER_H_ */
