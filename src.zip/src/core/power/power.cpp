/*
 * power.cpp
 */

#include "power.h"

Power::Power(int duration, int damageRange){
	this->name = "";
	this->duration = duration;
	this->damageRange = damageRange;
}

Power::~Power() {
}

// pos: get the name power
std::string Power::getPowerName(){
	return this->name;
}

// pos: get duration of the power
unsigned int Power::getDuration(){
	return this->duration;
}

// pos: get damage range of the power
int Power::getDamageRange(){
	return this->damageRange;
}

// pos: set the power name
void Power::setPowerName(std::string name){
	this->name = name;
}

// pos: set duration of the power
void Power::setDuration(unsigned int duration){
	this->duration = duration;
}

// pos: set damage range of the power
void Power::setDamageRange(int damageRange) {
	this->damageRange = damageRange;
}

// pos: activate the power
void Power::activatePower(){
}


