/*
 * board.cpp
 */

#include "board.h"

#include <iostream>
using namespace std;

Board::Board(BoardSize size)
{
    this->size = size;

    this->cellCube = new CellCube();
    for (int k = 0; k < size.levelCount; k++)
    {
        CellLevel *level = new CellLevel();

        for (int i = 0; i < size.rowCount; i++)
        {
            CellRow *row = new CellRow();

            for (int j = 0; j < size.columnCount; j++)
            {
                Position position = {j, i, k};
                row->append(new Cell(position));
            }
            level->append(row);
        }
        this->cellCube->append(level);
    }

    initializeCellNeighbours();
}

void Board::initializeCellNeighbours()
{
    // Set neighbors for each cell
    for (int k = 0; k < size.levelCount; k++)
    {
        for (int i = 0; i < size.rowCount; i++)
        {
            for (int j = 0; j < size.columnCount; j++)
            {
                Position position = {j, i, k};
                Cell *cell = getCell(position);

                // Capas acceder a las celdas usando la lista en vez de
                // este for para llamar a getCell sea mejor algoritmicamente
                for (int dz = -1; dz <= 1; dz++)
                {
                    for (int dy = -1; dy <= 1; dy++)
                    {
                        for (int dx = -1; dx <= 1; dx++)
                        {
                            if (dx == 0 && dy == 0 && dz == 0)
                                continue; // Skip the current cell

                            int neighborX = j + dx;
                            int neighborY = i + dy;
                            int neighborZ = k + dz;

                            if (neighborX >= 0 && neighborX < size.columnCount &&
                                neighborY >= 0 && neighborY < size.rowCount &&
                                neighborZ >= 0 && neighborZ < size.levelCount)
                            {
                                Position neighborPosition = {neighborX, neighborY, neighborZ};
                                Cell *neighbor = getCell(neighborPosition);
                                cell->setNeighbor(dx, dy, dz, neighbor);
                            }
                        }
                    }
                }
            }
        }
    }
}

Board::~Board()
{
    if (cellCube != NULL)
    {
        // Elimino niveles del cubo
        cellCube->resetCursor();
        while (cellCube->advanceCursor())
        {
            CellLevel *level = cellCube->getCursor();

            // Elimino filas del nivel
            level->resetCursor();
            while (level->advanceCursor())
            {
                CellRow *row = level->getCursor();

                // Elimino celdas de las filas
                row->resetCursor();
                while (row->advanceCursor())
                {
                    Cell *cell = row->getCursor();
                    delete cell;
                }

                delete row;
            }

            delete level;
        }

        delete cellCube;
    }
}

CellCube *Board::getCellCube() const
{
    if (this->cellCube == NULL)
    {
        throw "El cubo no está definido";
    }

    return this->cellCube;
}

BoardSize Board::getSize() const
{
    return this->size;
}

Cell *Board::getCell(Position pos) const
{
    if (!isValidPosition(pos))
    {
        throw "La posicion no es valida";
    }

    return cellCube->get(pos.z + 1)->get(pos.y + 1)->get(pos.x + 1);
}

bool Board::isValidPosition(Position pos) const
{
    return (0 <= pos.x && pos.x < size.columnCount) &&
           (0 <= pos.y && pos.y < size.rowCount) &&
           (0 <= pos.z && pos.z < size.levelCount);
}
