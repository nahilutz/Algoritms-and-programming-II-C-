/*
 * board.h
 *
 */

#ifndef CORE_BOARD_H_
#define CORE_BOARD_H_

#include "../core.h"
#include "../cell/cell.h"
#include "../structure/list.h"

struct BoardSize
{
    int rowCount;
    int columnCount;
    int levelCount;
};

typedef List<Cell *> CellRow;
typedef List<CellRow *> CellLevel;
typedef List<CellLevel *> CellCube;

class Board
{
private:
    BoardSize size;
    CellCube *cellCube;

private:
    /*
     *  PRE: -
     *  POS: Establece las celdas vecinas de cada celda en todo el tablero
     */
    void initializeCellNeighbours();

public:
    /*
     * PRE: Las medidas del tablero deben ser mayor a 0
     * POS: Crea una instancia del tablero con su respectivo tamaño
     */
    Board(BoardSize size);

    /*
     * PRE: -
     * POS: Destruye la instancia del jugador y libera recursos.
     */
    ~Board();

    /*
     * PRE: la matriz debe estar creada e inicializada.
     * POS: devuelve un puntero a la matriz.
     */
    CellCube *getCellCube() const;

    /*
     * PRE: La posicion debe estar dentro de las medidas del tablero
     * POS: Devuelve la celda en dicha posicion
     */
    Cell *getCell(Position pos) const;

    /*
     * PRE: -
     * POS: Devuelve true si la posicion es valida dentro del tablero
     */
    bool isValidPosition(Position pos) const;

    /*
     * PRE: -
     * POS: Devuelve la posicion del tablero
     */
    BoardSize getSize() const;
};

#endif /* CORE_BOARD_H_ */
