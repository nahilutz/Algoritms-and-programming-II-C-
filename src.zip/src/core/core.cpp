/*
 * core.cpp
 */

#include "core.h"
using namespace std;

void core::initializeRng()
{
	srand(time(NULL));
}

int core::generateRandomInt(int a, int b)
{
	if (b < a)
	{
		throw "El extremo superio \"b\" deber ser mayor o igual al extremo inferior \"a\"";
	}

	return a + rand() % (b - a + 1);
}

double core::generateRandomDouble()
{
	return (double)rand() / RAND_MAX;
}

Position core::generateRandomPosition(int rowCount, int columnCount, int levelCount)
{
	Position pos;

	pos.x = generateRandomInt(0, rowCount - 1);
	pos.y = generateRandomInt(0, columnCount - 1);
	pos.z = generateRandomInt(0, levelCount - 1);

	return pos;
}

bool core::isUniquePosition(Position position, PositionList *positionList)
{
	if (positionList == NULL)
	{
		throw "La lista de posiciones debe ser no nula";
	}

	positionList->resetCursor();
	while (positionList->advanceCursor())
	{
		Position currentPosition = positionList->getCursor();

		if (position.x == currentPosition.x && position.y == currentPosition.y && position.z == currentPosition.z)
		{
			return false;
		}
	}

	return true;
}
