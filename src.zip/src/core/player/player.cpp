/*
 * player.cpp
 *
 */

#include "player.h"

using namespace std;

Player::Player(int number)
{
    if (number <= 0)
    {
        throw "El número del jugador debe ser mayor a cero.";
    }

    stringstream ss;

    this->number = number;

    ss << "Jugador " << number;
    this->name = ss.str();

    this->status = ACTIVE;
}

Player::~Player()
{
}

Status Player::getStatus() const
{
    return this->status;
}

bool Player::isActive() const
{
    return this->status == ACTIVE;
}

string Player::getName() const
{
    return this->name;
}

int Player::getNumber() const
{
    return this->number;
}