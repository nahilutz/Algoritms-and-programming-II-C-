/*
 * player.h
 *
 */

#ifndef CORE_PLAYER_PLAYER_H_
#define CORE_PLAYER_PLAYER_H_

#include <iostream>
#include <sstream>

#include "../../core/core.h"

class Player
{
private:
	int number;
	std::string name;
	Status status;

public:
	/*
	 * PRE: El numero del jugador debe ser mayor a cero.
	 * POS: Crea una instancia del jugador con un número dado.
	 */
	Player(int number);
	/*
	 * PRE: -
	 * POS: Destruye la instancia del jugador y libera recursos.
	 */
	virtual ~Player();
	/*
	 * PRE: -
	 * POS: Devuelve el estado del jugador.
	 */
	virtual Status getStatus() const;
	/*
	 * PRE: -
	 * POS: Indica si el jugador está activo o no.
	 */
	virtual bool isActive() const;
	/*
	 * PRE: -
	 * POS: Devuelve el nombre del jugador.
	 */
	std::string getName() const;
	/*
	 * PRE: -
	 * POS: Devuelve el número del jugador.
	 */
	int getNumber() const;
};

#endif /* CORE_PLAYER_PLAYER_H_ */
