/*
 * core.h
 *
 */

#ifndef CORE_CORE_H_
#define CORE_CORE_H_

#include <iostream>

#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <vector>

#include "structure/list.h"

static const double PI = 3.14159265359;

// Estado base genérico
enum Status
{
	ACTIVE,
	DEFEATED
};

// Terreno de una celda
enum CellTerrain
{
	GROUND,
	WATER,
	AIR
};

struct Position
{
	int x;
	int y;
	int z;

	Position operator+(const Position &p)
	{
		Position newPos = {this->x + p.x, this->y + p.y, this->z + p.z};
		return newPos;
	}

	Position operator-(const Position &p)
	{
		Position newPos = {this->x - p.x, this->y - p.y, this->z - p.z};
		return newPos;
	}
};

typedef List<Position> PositionList;

struct RelativePosition
{
	Position origin;
	Position relative;
};

typedef List<RelativePosition> RelativePositionList;

namespace core
{
	/*
	 * PRE: -
	 * POS: Inicializa el generador de numeros aleatoreos.
	 */
	void initializeRng();
	/*
	 * PRE: El extremo superio "b" debe ser mayor al entremo inferior "a".
	 * POS: Genera un entero aleatorio entre [a,b].
	 */
	int generateRandomInt(int a, int b);
	/*
	 * PRE: -
	 * POS: Genera un numero real aleatorio entre [0,1].
	 */
	double generateRandomDouble();
	/*
	 * PRE: Todas las dimensiones deben ser mayores a cero.
	 * POS: Genera una posición aleatoria en le cububo rowCount x columnCount x levelCount.
	 */
	Position generateRandomPosition(int rowCount, int columnCount, int levelCount);
	/*
	 * PRE: La lista de posiciones no debe ser nula.
	 * POS: Verifica si la posición se encuentra en la lista de posiciones.
	 */
	bool isUniquePosition(Position position, PositionList *positionList);
}

#endif /* CORE_CORE_H_ */
