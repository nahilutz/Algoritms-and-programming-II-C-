/*
 * mine.cpp
 */

#include "mine.h"

Mine::Mine(Position pos, Player *owner, unsigned int explosivePower) : BoardToken(pos, owner)
{
    this->explosivePower = explosivePower;
}

Mine::~Mine()
{
}

void Mine::setExplosivePower(unsigned int explosivePower)
{
    this->explosivePower = explosivePower;
}

unsigned int Mine::getExplosivePower() const
{
    return this->explosivePower;
}

unsigned int Mine::explode()
{
    unsigned int power = this->explosivePower;
    // delete this;
    return power;
}