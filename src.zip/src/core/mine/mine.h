/*
 * mine.h
 */

#ifndef CORE_MINE_MINE_H_
#define CORE_MINE_MINE_H_

#include "../board-token/board-token.h"

class Mine : public BoardToken
{
private:
	unsigned int explosivePower;

public:
	static const int DEFAULT_EXPLOSIVE_POWER = 5;

	/*
	 * PRE: @param pos: Mine position; @param owner: Mine owner ; @param explosivePower : how many turns will disable the cell when it explodes is optional with Default value = DEFAULT_EXPLOSIVE_POWER
	 * POS: Creates a mine at a board position for a player.
	 */
	Mine(Position pos, Player *owner, unsigned int explosivePower = DEFAULT_EXPLOSIVE_POWER);
	/*
	 * PRE:
	 * POS:Deletes the Object
	 */
	~Mine();

	/*
	 * PRE: @param uint explosivePower: how many turns will disable the cell when it explodes
	 * POS: Sets the explosive power of the mine
	 */
	void setExplosivePower(unsigned int explosivePower);

	/*
	 * PRE:
	 * POS: Gets the explosivePower of the mine  @returns unsigned int explosivePower wich is how many turns will disable the cell when it explodes
	 */
	unsigned int getExplosivePower() const;

	/*
	 * PRE:
	 * POS:returns the explosivePower @returns explosivePower (is redundant but was considering destroying the object in this function.)
	 */
	unsigned int explode();
};

#endif /* CORE_MINE_MINE_H_ */
