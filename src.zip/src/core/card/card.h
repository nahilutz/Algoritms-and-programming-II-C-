/*
 * card.h
 */
#ifndef CORE_CARD_CARD_H_
#define CORE_CARD_CARD_H_

#include "../power/power.h"

enum CardStatus
{
	ENABLED,
	DISABLED
};

class Card
{
private:
	Power *power;
	CardStatus status;

public:
	/*
	 * PRE: Receive a power with which the letter will be generated
	 * POS: Create an instance of a card
	 */
	Card(Power *power);
	
	/* Destructor */
	~Card();
	
	/*
	 * PRE: -
	 * POS: Activate a card with power within the deck.
	 */
	void activateCard();
	
	/*
	 * PRE: -
	 * POS: Return status of the card
	 */
	CardStatus getStatus() const;
	
	/*
	 * PRE: -
	 * POS: Indica si la carta esta habilitada o no.
	 */
	bool isEnabled() const;
	
	/*
	 * PRE: -
	 * POS: return the power name
	 */
	std::string getName();
};

#endif /* CORE_CARD_CARD_H_ */
