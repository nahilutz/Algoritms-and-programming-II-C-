/*
 * card.cpp
 */

#include "card.h"

Card::Card(Power *power)
{
	this->power = power;
	this->status = ENABLED;
}

Card::~Card()
{
	delete power;
}

// pos: call the activate method of the power effect card
void Card::activateCard()
{
	this->power->activatePower();
	this->status = DISABLED;
}

// pos: return the current card status
CardStatus Card::getStatus() const
{
	return this->status;
}

bool Card::isEnabled() const
{
	return this->status == ENABLED;
}

// post: return the power name
std::string Card::getName()
{
	return this->power->getPowerName();
}