/*
 * board-token.h
 */

#ifndef CORE_BOARD_TOKEN_BOARD_TOKEN_H_
#define CORE_BOARD_TOKEN_BOARD_TOKEN_H_

#include "../core.h"
#include "../player/player.h"

class BoardToken
{
protected:
	Position position;
	Player *owner;
	Status status;
	CellTerrain allowedTerrain;

public:
	// Created an instance of BoardToken at a certain position
	// for a player
	// @param pos: token position.
	// @param owner: token owner.
	BoardToken(Position pos, Player *owner);

	// Destroys the object.
	virtual ~BoardToken();

	// Gets the token position
	Position getPosition() const;

	// Get the token owner
	Player *getOwner() const;

	// Moves the token
	// @param newPos: New position
	virtual void move(Position newPosition);
	/*
	 * PRE: -
	 * POS: Devuelve el estado de la ficha.
	 */
	virtual Status getStatus() const;
	/*
	 * PRE: -
	 * POS: Verifica si la ficha está activa.
	 */
	virtual bool isActive() const;
	/*
	 * PRE: -
	 * POS: Destruye la ficha.
	 */
	virtual void destroy();
	/*
	 * PRE: -
	 * POS: Devuelve el terreno válido para la ficha.
	 */
	CellTerrain getAllowedTerrain() const;
	/*
	 * PRE: -
	 * POS: Establece el terreno válido para la ficha.
	 */
	void setAllowedTerrain(CellTerrain terrain);
};

#endif /* CORE_BOARD_TOKEN_BOARD_TOKEN_H_ */
