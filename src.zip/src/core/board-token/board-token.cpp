/*
 * board-token.cpp
 */

#include "board-token.h"

BoardToken::BoardToken(Position pos, Player *owner)
{
	this->position = pos;
	this->owner = owner;
	this->status = ACTIVE;
	this->allowedTerrain = GROUND;
}

BoardToken::~BoardToken()
{
}

Position BoardToken::getPosition() const
{
	return this->position;
}

Player *BoardToken::getOwner() const
{
	return this->owner;
}

void BoardToken::move(Position newPosition)
{
	this->position = newPosition;
}

Status BoardToken::getStatus() const
{
	return this->status;
}

bool BoardToken::isActive() const
{
	return this->status == ACTIVE;
}

void BoardToken::destroy()
{
	this->position.x = -1;
	this->position.y = -1;
	this->position.z = -1;
	this->status = DEFEATED;
}

CellTerrain BoardToken::getAllowedTerrain() const
{
	return this->allowedTerrain;
}

void BoardToken::setAllowedTerrain(CellTerrain terrain)
{
	this->allowedTerrain = terrain;
}
