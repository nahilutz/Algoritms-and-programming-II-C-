/*
 * airship.h
 */

#ifndef CORE_Airship_H_
#define CORE_Airship_H_

#include "../core.h"
#include "../board-token/board-token.h"

class Airship : public BoardToken
{
public:
    /*
     * PRE:
     * POS: Creates an Airship @param pos: Airship position @param owner: Airship owner
     */
    Airship(Position pos, Player *owner);
};

#endif /* CORE_Airship_Airship_H_ */
