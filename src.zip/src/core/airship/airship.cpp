/*
 * airship.cpp
 */

#include "airship.h"

Airship::Airship(Position pos, Player *owner) : BoardToken(pos, owner)
{
}
