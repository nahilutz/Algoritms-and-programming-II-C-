/*
 * Navy.h
 */

#ifndef CORE_WARSHIP_H_
#define CORE_WARSHIP_H_

#include "../core.h"
#include "../board-token/board-token.h"

class Warship : public BoardToken
{
public:
	/*
	 * PRE: @param pos: soldier position @param owner: soldier owner
	 * POS: Creates a Warship at a board position.
	 */
	Warship(Position pos, Player *owner);
};

#endif /* CORE_WARSHIP_WARSHIP_H_ */
