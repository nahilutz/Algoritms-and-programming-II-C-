/*
 * Navy.cpp
 */

#include "warship.h"

Warship::Warship(Position pos, Player *owner) : BoardToken(pos, owner)
{
}