/*
 * soldier.cpp
 */

#include "soldier.h"

Soldier::Soldier(Position pos, Player *owner) : BoardToken(pos, owner)
{
}
