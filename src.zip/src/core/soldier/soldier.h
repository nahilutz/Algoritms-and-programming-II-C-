/*
 * soldier.h
 */

#ifndef CORE_SOLDIER_SOLDIER_H_
#define CORE_SOLDIER_SOLDIER_H_

#include "../core.h"
#include "../board-token/board-token.h"

class Soldier : public BoardToken
{
public:
	/*
	 * PRE: Creates a soldier at a board position. @param pos: soldier position @param owner: soldier owner
	 * POS: Creates an instance of the Soldier with a given position.
	 */
	Soldier(Position pos, Player *owner);
};

#endif /* CORE_SOLDIER_SOLDIER_H_ */
