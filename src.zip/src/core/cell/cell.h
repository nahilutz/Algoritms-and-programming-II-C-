/*
 * cell.h
 */

#ifndef CORE_CELL_CELL_H_
#define CORE_CELL_CELL_H_

#include "../core.h"
#include "../board-token/board-token.h"

#include "../structure/list.h"

enum CellStatus
{
	EMPTY,
	FULL,
	DEACTIVATED,
	MARKED,
};

class Cell;
typedef List<Cell *> CellList;

class Cell
{
private:
	static const int SPACE_DIMENSION_LENGTH = 3;
	Position pos;
	CellStatus status;
	CellStatus prevStatus;
	CellTerrain terrain;
	BoardToken *boardToken;
	int deactivationTimer;
	Cell *neighbors[SPACE_DIMENSION_LENGTH][SPACE_DIMENSION_LENGTH][SPACE_DIMENSION_LENGTH];

public:
	/*
	 * PRE: Recives a position and a terrain @param: position pos where is the cell located; @param: terrain of the cell
	 * POS: Creates a cell on pos position and with the terrain Terrain
	 */
	Cell(Position pos, CellTerrain terrain = AIR);
	/*
	 * PRE: -
	 * POS: Destruye la instancia de la celda
	 */
	virtual ~Cell();
	/*
	 * PRE: -
	 * POS: Devuelve la posición de la celda
	 */
	Position getPosition() const;
	/*
	 * PRE: -
	 * POS: Devuelve el estado de la celda.
	 */
	CellStatus getStatus() const;
	/*
	 * PRE: Centrado en la celda. La coordenadas x,y,z del vecino están en el rango [-1;1].
	 *		-1 indica a izquierda. +1 indica a derecha.
	 * POS: Devuelve un puntero a la celda vecina en requerida o NULL si está fuera de los límites.
	 */
	Cell *getNeighbor(int x, int y, int z) const;
	/*
	 * PRE: -
	 * POS: Devuelve una nueva lista con todas las celdas vecinas de la celda actual.
	 */
	CellList *getAllNeighbors() const;
	/*
	 * PRE: neighbor no es nullptr
	 * POS: Establece la celda 'neighbor' como vecina en la posición (x, y, z)
	 */
	void setNeighbor(int x, int y, int z, Cell *neighbor);
	/*
	 * PRE: La ficha debe ser no nula
	 * POS: Vincula una ficha con la celda.
	 */
	void linkBoardToken(BoardToken *boardToken);
	/*
	 * PRE: -
	 * POS: Devuelve la ficha asociada a la celda o NULL si no hay ficha.
	 */
	BoardToken *getLinkedBoardToken() const;
	/*
	 * PRE: -
	 * POS: Devuelve el terreno de la celda.
	 */
	CellTerrain getTerrain() const;
	/*
	 * PRE: -
	 * POS: Establece el terreno de la celda.
	 */
	CellTerrain setTerrain(CellTerrain newTerrain);
	/*
	 * PRE: -
	 * POS: Establece la selda como marcada y almacena el estada anterior.
	 */
	void mark();
	/*
	 * PRE: -
	 * POS: Desmarca la celda y recupera el estado anterior.
	 */
	void unmark();
	/*
	 * PRE: -
	 * POS: Verifica si la celda está desactivada.
	 */
	bool isDeactivated() const;
	/*
	 * PRE: -
	 * POS: Verifica si la celda está marcada.
	 */
	bool isMarked() const;
	/*
	 * PRE: -
	 * POS: Verifica si la celda está vacía.
	 */
	bool isEmpty() const;
	/*
	 * PRE: -
	 * POS: Limpia el contenido de la celda.
	 */
	void clear();
	/*
	 * PRE: -
	 * POS: Verifica si la celda tiene una ficha.
	 */
	bool hasBoardToken() const;
	/*
	 * PRE: El tiempo de desativación debe ser mayor a cero.
	 * POS: Numero de turnos que tarda en recuperar el estado VACIOS. @param deactivationTime: Debe ser mayor a cero
	 */
	void setDeactivationTimer(int deactivationTime);
	/*
	 * PRE: -
	 * POS: Actualiza el timer de desactivación de la celda si la celda está desactivada.
	 */
	void updateDeactivationTimer();
};

#endif /* CORE_CELL_CELL_H_ */
