/*
 * cell.cpp
 */

#include "cell.h"

using namespace std;

Cell::Cell(Position pos, CellTerrain terrain)
{

	this->status = EMPTY;
	this->prevStatus = EMPTY;
	this->deactivationTimer = 0;
	this->pos = pos;
	this->boardToken = NULL;
	this->terrain = terrain;
}

Cell::~Cell()
{
	this->boardToken = NULL;
}

Position Cell::getPosition() const
{
	return this->pos;
}

CellStatus Cell::getStatus() const
{
	return this->status;
}

Cell *Cell::getNeighbor(int x, int y, int z) const
{
	bool isZeroVector = (x * x + y * y + z * z) == 0;

	if ((-1 <= x && x <= 1) && (-1 <= y && y <= 1) && (-1 <= z && z <= 1) && !isZeroVector)
	{
		return neighbors[x + 1][y + 1][z + 1];
	}
	else
	{
		return NULL;
	}
}

CellList *Cell::getAllNeighbors() const
{
	CellList *allNeighbours = new CellList();

	for (int x = 0; x < SPACE_DIMENSION_LENGTH; x++)
	{
		for (int y = 0; y < SPACE_DIMENSION_LENGTH; y++)
		{
			for (int z = 0; z < SPACE_DIMENSION_LENGTH; z++)
			{
				if (neighbors[x][y][z] != NULL)
				{
					allNeighbours->append(neighbors[x][y][z]);
				}
			}
		}
	}

	return allNeighbours;
}

void Cell::setNeighbor(int x, int y, int z, Cell *neighbor)
{
	bool isZeroVector = (x * x + y * y + z * z) == 0;

	if ((-1 <= x && x <= 1) && (-1 <= y && y <= 1) && (-1 <= z && z <= 1) && !isZeroVector)
	{
		neighbors[x + 1][y + 1][z + 1] = neighbor;
	}
}

void Cell::linkBoardToken(BoardToken *boardToken)
{
	this->boardToken = boardToken;
	this->status = boardToken != NULL ? FULL : EMPTY;
}

BoardToken *Cell::getLinkedBoardToken() const
{
	return this->boardToken;
}

CellTerrain Cell::getTerrain() const
{
	return this->terrain;
}

CellTerrain Cell::setTerrain(CellTerrain newTerrain)
{
	return this->terrain = newTerrain;
}

void Cell::mark()
{
	this->prevStatus = this->status;
	this->status = MARKED;
}

void Cell::unmark()
{
	this->status = this->prevStatus;
}

void Cell::setDeactivationTimer(int deactivationTime)
{
	if (deactivationTime > 0)
	{
		this->deactivationTimer = deactivationTime;
		this->status = DEACTIVATED;
	}
}

void Cell::updateDeactivationTimer()
{
	if (isDeactivated())
	{
		this->deactivationTimer--;

		if (this->deactivationTimer == 0)
		{
			this->status = EMPTY;
		}
	}
}

bool Cell::hasBoardToken() const
{
	return this->boardToken != NULL;
}

bool Cell::isDeactivated() const
{
	return this->status == DEACTIVATED;
}

bool Cell::isMarked() const
{
	return this->status == MARKED;
}

bool Cell::isEmpty() const
{
	return this->status == EMPTY;
}

void Cell::clear()
{
	this->boardToken = NULL;
	this->status = EMPTY;
	this->prevStatus = EMPTY;
}
