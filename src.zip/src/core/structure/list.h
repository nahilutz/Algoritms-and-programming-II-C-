
#ifndef CORE_STRUCTURE_LIST_H_
#define CORE_STRUCTURE_LIST_H_

#ifndef NULL
#define NULL 0
#endif /* NULL */

#include "node.h"

template<class T> class List {
	private:
		Node<T>* first;
		unsigned int size;
		Node<T>* cursor;

	public:
		List();
		List(List<T> &newList);
		bool isEmpty()const;
		unsigned int elementCount()const;
		void append(T element);
		void insert(T element, unsigned int position);
		void append(List<T> &otherList);
		T get(unsigned int position);
		void assign(T element, unsigned int position);
		void remove(unsigned int position);
		void resetCursor();
		bool advanceCursor();
		T getCursor()const;
		~List();

	private:
		Node<T>* getNode(unsigned int position)const;
};


/*	IMPLEMENTATION	*/

/* PUBLIC: */

/* POST: Empty list. */
template<class T> List<T>::List(){
	this->first = NULL;
	this->size = 0;
	this->cursor = NULL;
}

/* POST: List equal to passed list. */
template<class T> List<T>::List(List<T> &newList){
	this->first = NULL;
	this->size = 0;
	this->cursor = NULL;
	this->append(newList);
}

/* POST: Tells whether the list has any element. */
template<class T> bool List<T>::isEmpty()const{
	return (this->size == 0);
}

/* POST: Returns the amount of elements in the list. */
template<class T> unsigned int List<T>::elementCount()const{
	return (this->size);
}

/* POST: Adds element at the end of the list (position countElements() + 1). */
template<class T> void List<T>::append(T element){
	this->insert(element, this->size + 1);
}

/* PRE: Position is between [1 , countElements() + 1].
 * POST: Adds the element in passed position. */
template<class T> void List<T>::insert(T element, unsigned int position){
	if((position > 0) && (position <= this->size + 1)){ /* posición válida */
		Node<T>* newNode = new Node<T>(element);
		if(position == 1){
			newNode->setNext(this->first);
			this->first = newNode;
		} else{
			Node<T>* previousNode = this->getNode(position - 1);
			newNode->setNext(previousNode->getNext());
			previousNode->setNext(newNode);
		}
		this->size++;
		this->resetCursor();
	}
}

/* POST: Adds all elements from passed list at the end of the list,
 *  that's from position countElements() + 1. */
template<class T> void List<T>::append(List<T> &otherList){
	otherList.resetCursor();
	while(otherList.advanceCursor()){
		this->append(otherList.getCursor());
	}
}

/* PRE: Position is between [1 , countElements()].
 * POST: Returns the element in that position. */
template<class T> T List<T>::get(unsigned int position){
	if((position <= 0) || (position > this->size)){
		throw "POSICION INVALIDA";
	}
	return (this->getNode(position)->getValue());
}

/* PRE: Position is between [1 , countElements()].
 * POST: Changes element in that position to passed element. */
template<class T> void List<T>::assign(T element, unsigned int position){
	if((position > 0) && (position <= this->size)){
		this->getNode(position)->setValue(element);
	}
}

/* PRE: Position is between [1 , countElements()].
 * POST: Removes element in that position from the list. */
template<class T> void List<T>::remove(unsigned int position){
	if((position > 0) && (position <= this->size)){
		Node<T>* removedNode;
		if(position == 1){
			removedNode = this->first;
			this->first = this->first->getNext();
		} else{
			Node<T>* previousNode = this->getNode(position - 1);
			removedNode = previousNode->getNext();
			previousNode->setNext(removedNode->getNext());
		}
		delete removedNode;
		this->size--;
		this->resetCursor();
	}
}

/* POST: Leaves cursor ready for new iteration. */
template<class T> void List<T>::resetCursor(){
	this->cursor = NULL;
}

/* Allows to move the cursor from a node to the next one.
 * PRE: Iteration has been initiated (by method resetCursor()),
 *  and no elements have been added or removed since then.
 * POST: Moves cursor to the next element in the iteration.
 *  Return value tells whether cursor now stands on and element or not,
 *  (in case the list is empty or there aren't any more elements). */
template<class T> bool List<T>::advanceCursor(){
	if(this->cursor == NULL){
		this->cursor = this->first;
	} else{
		this->cursor = this->cursor->getNext();
	}
	return (this->cursor != NULL);
}

/* PRE: Cursor is standing on an element of the list,
 *  (method advanceCursor() was called and returned "true").
 * POST: Returns element in the cursor's position. */
template<class T> T List<T>::getCursor()const{
	if(this->cursor == NULL){
		throw "CURSOR ESTA NULL";
	}
	return (this->cursor->getValue());
}

/* POST: Liberates resources associated to the list. */
template<class T> List<T>::~List(){
	while(this->first != NULL){
		Node<T>* removedNode = this->first;
		this->first = this->first->getNext();
		delete removedNode;
	}
}

/* PRIVATE: */

/* PRE: Position is between [1 , countElements()].
 * POST: Returns the node in that position (pointer). */
template<class T> Node<T>* List<T>::getNode(unsigned int position)const{
	Node<T>* currentNode = this->first;
	for(unsigned int i = 1; i < position; i++){
		currentNode = currentNode->getNext();
	}
	return currentNode;
}


#endif /* CORE_STRUCTURE_LIST_H_ */
