
#ifndef CORE_STRUCTURE_NODE_H_
#define CORE_STRUCTURE_NODE_H_

#ifndef NULL
#define NULL 0
#endif /* NULL */

template<class T> class Node{
private:
	T value;
	Node<T>* next;
public:
	Node(T value);
	bool hasNext();
	Node<T>* getNext();
	void setNext(Node<T>* newNext);
	T getValue();
	void setValue(T newValue);
	~Node();
};


template<class T> Node<T>::Node(T value){
	this->value = value;
	this->next = NULL;
}

template<class T> bool Node<T>::hasNext(){
	return (this->next != NULL);
}

template<class T> Node<T>* Node<T>::getNext(){
	return (this->next);
}

template<class T> void Node<T>::setNext(Node<T>* newNext){
	this->next = newNext;
}

template<class T> T Node<T>::getValue(){
	return (this->value);
}

template<class T> void Node<T>::setValue(T newValue){
	this->value = newValue;
}

template<class T> Node<T>::~Node(){

}


#endif /* CORE_STRUCTURE_NODE_H_ */
