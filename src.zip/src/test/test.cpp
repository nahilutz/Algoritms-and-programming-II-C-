/*
 * test.cpp
 *
 */

#include "test.h"

void tst::testCell()
{
    Position pos = {1, 1, 1};
    CellTerrain terrain = GROUND;
    Cell *cell = new Cell(pos, terrain);
    std::cout << cell->getTerrain() << std::endl;
    terrain = AIR;
    cell->setTerrain(terrain);
    std::cout << cell->getTerrain() << std::endl;
    delete cell;
}

void tst::testMine()
{
    Position pos = {1, 1, 1};
    Player *player = new Player(1);
    Mine *mina = new Mine(pos, player, 43);
    std::cout << mina->getExplosivePower() << std::endl;
    mina->setExplosivePower(3);
    std::cout << mina->explode() << std::endl;
    delete mina;
    delete player;
}

void tst::testAircraft()
{
    Position pos = {1, 1, 1};
    Player *player = new Player(1);

    Airship *airship = new Airship(pos, player);

    std::cout << airship->getStatus() << std::endl;
    airship->destroy();
    std::cout << airship->getStatus() << std::endl;

    delete airship;
    delete player;
}

void tst::testBoardPrinting()
{
    Commander *commander = new Commander(1);
    Screen screen = Screen::getInstance();

    BoardSize size = {20, 20, 20};
    Board *board = new Board(size);

    screen.printBoard(board, commander);

    delete board;
    delete commander;
}
