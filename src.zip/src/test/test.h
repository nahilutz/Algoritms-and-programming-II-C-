/*
 * test.h
 *
 */

#ifndef TEST_TEST_H_
#define TEST_TEST_H_

#include "../core/core.h"
#include "../core/board/board.h"
#include "../screen/screen.h"
#include "../core/cell/cell.h"
#include "../core/airship/airship.h"
#include "../core/mine/mine.h"

namespace tst
{
    void testAircraft();
    void testMine();
    void testCell();
    void testBoardPrinting();
}

#endif /* TEST_TEST_H_ */
