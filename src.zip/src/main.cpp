/*
 * TP2 Batalla Digital 2.0
 *
 * Grupo: Milanesa de pebete
 * Integrantes:
 * 		- Baleani, Sebastián 	94451
 * 		- Hisas, Cristian 		105134
 * 		- Domínguez, Ignacio	102799
 *		- Mortimer, Federica	108034
 *		-
 *		-
 */

#include <iostream>
using namespace std;

#include "board-game/board-game.h"
#include "test/test.h"

int main()
{
	core::initializeRng();

	GameConfig *gameConfig = BoardGame::startGameConfigDialog();

	BoardGame *boardGame = new BoardGame(gameConfig);

	boardGame->start();

	delete boardGame;

	return 0;
}
