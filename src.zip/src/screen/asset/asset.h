/*
 * asset.h
 */

#ifndef SCREEN_ASSET_ASSET_H_
#define SCREEN_ASSET_ASSET_H_

#include <iostream>

enum AssetType
{
	IMAGE,
	AUDIO,
	VIDEO
};

class Asset
{
private:
	std::string path;
	AssetType type;

public:
	/*
	 * PRE: La ruta debe ser no vacía.
	 * POS: Crea el asset a partir de la ruta y el tipo.
	 */
	Asset(std::string path, AssetType type);
	/*
	 * PRE:
	 * POS: Destruye la instancia del assets y libera recursos.
	 */
	virtual ~Asset();
	/*
	 * PRE: -
	 * POS: Devuelve la ruta del asset.
	 */
	std::string getPath() const;
	/*
	 * PRE: -
	 * POS: Devuelve el tipo de asset.
	 */
	AssetType getType() const;
};

#endif /* SCREEN_ASSET_ASSET_H_ */
