/*
 * asset.cpp
 */

#include "asset.h"

using namespace std;

Asset::~Asset()
{
}

Asset::Asset(string path, AssetType type)
{
	this->path = path;
	this->type = type;
}

string Asset::getPath() const
{
	return this->path;
}

AssetType Asset::getType() const
{
	return this->type;
}
