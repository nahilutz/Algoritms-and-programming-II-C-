/*
 * msg.cpp
 */

#include "screen.h"
using namespace std;

#include <list>
#include <string>

Screen::Screen()
{
	// Inicializo los assets de los terrenos de las celdas
	stringstream ss;

	this->assetMap[getBackgroundLabel()] = new Asset("assets/background.bmp", IMAGE);
	this->assetMap[getcharsetLabel()] = new Asset("assets/charset.bmp", IMAGE);

	ss << getTerrainLabel() << GROUND;
	this->assetMap[ss.str()] = new Asset("assets/ground-tile.bmp", IMAGE);
	ss.str("");
	ss << getTerrainLabel() << WATER;
	this->assetMap[ss.str()] = new Asset("assets/water-tile.bmp", IMAGE);
	ss.str("");
	ss << getTerrainLabel() << AIR;
	this->assetMap[ss.str()] = new Asset("assets/air-tile.bmp", IMAGE);
	ss.str("");

	// Inicializo los assets de los estados de las celdas
	ss << getCellStatusLabel() << DEACTIVATED;
	this->assetMap[ss.str()] = new Asset("assets/cell-deactivated.bmp", IMAGE);
	ss.str("");
	ss << getCellStatusLabel() << MARKED;
	this->assetMap[ss.str()] = new Asset("assets/cell-marked.bmp", IMAGE);
	ss.str("");

	// Inicializo los assets de los soldados y armamentos
	this->assetMap[typeid(Soldier).name()] = new Asset("assets/soldier.bmp", IMAGE);
	this->assetMap[typeid(Mine).name()] = new Asset("assets/mine.bmp", IMAGE);
	this->assetMap[typeid(Airship).name()] = new Asset("assets/airship.bmp", IMAGE);
	this->assetMap[typeid(Warship).name()] = new Asset("assets/warship.bmp", IMAGE);
}

Screen::~Screen()
{
	// Libero todos los assets
	for (AssetMap::iterator it = this->assetMap.begin(); it != this->assetMap.end(); ++it)
	{
		delete it->second;
	}
}

void Screen::displayAssetMap()
{
	for (AssetMap::iterator it = this->assetMap.begin(); it != this->assetMap.end(); ++it)
	{
		cout << "key: " << it->first << " value: " << it->second->getPath() << endl;
	}
}

string Screen::getTerrainLabel() const
{
	return "terrain#";
}

string Screen::getCellStatusLabel() const
{
	return "cell-status#";
}

string Screen::getBackgroundLabel() const
{
	return "background";
}

string Screen::getcharsetLabel() const
{
	return "charset";
}

void Screen::printTitle() const
{
	logger().writeLine("=====================================");
	logger().writeLine("\tBatalla Digital 2.0");
	logger().writeLine("=====================================");
}

GameConfig *Screen::startGameConfigDialog() const
{
	int *values = new int[GameConfig::PARAMETER_COUNT];

	// Mensajes de ingreso de parámetros de juego
	string *messages = new string[GameConfig::PARAMETER_COUNT];
	messages[0] = "Ingrese la cantidad de jugadores: ";
	messages[1] = "Ingrese la cantidad de filas que tiene cada nivel del tablero: ";
	messages[2] = "Ingrese la cantidad de columnas que tiene cada nivel del tablero: ";
	messages[3] = "Ingrese la cantidad de niveles que tiene cada nivel del tablero: ";

	// Matriz de limites
	int **limits = new int *[GameConfig::PARAMETER_COUNT];
	for (int i = 0; i < GameConfig::PARAMETER_COUNT; i++)
	{
		limits[i] = new int[2];
	}
	limits[0][0] = GameConfig::MINIMUM_PLAYER_COUNT;
	limits[0][1] = GameConfig::MAXIMUM_PLAYER_COUNT;

	limits[1][0] = GameConfig::MINIMUM_BOARD_ROW_COUNT;
	limits[1][1] = GameConfig::MAXIMUM_BOARD_ROW_COUNT;

	limits[2][0] = GameConfig::MINIMUM_BOARD_COLUMN_COUNT;
	limits[2][1] = GameConfig::MAXIMUM_BOARD_COLUMN_COUNT;

	limits[3][0] = GameConfig::MINIMUM_BOARD_LEVEL_COUNT;
	limits[3][1] = GameConfig::MAXIMUM_BOARD_LEVEL_COUNT;

	// Mensajes de error
	string *errors = new string[GameConfig::PARAMETER_COUNT];

	for (int i = 0; i < GameConfig::PARAMETER_COUNT; i++)
	{
		stringstream ss;
		ss << "ERROR: El parámetro está fuera de rango [" << limits[i][0] << ";" << limits[i][1] << "].";
		string aux = ss.str();
		errors[i] = aux;
	}

	for (int i = 0; i < GameConfig::PARAMETER_COUNT; i++)
	{
		bool validValue = false;
		logger().writeLine();
		while (!validValue)
		{
			logger().write(messages[i]);
			values[i] = readValue<int>();

			validValue = limits[i][0] <= values[i] && values[i] <= limits[i][1];
			if (!validValue)
			{
				logger().writeLine(errors[i]);
				logger().writeLine();
			}
		}
	}

	GameConfig *gameConfig = new GameConfig(values[0], values[1], values[2], values[3]);

	// ----------------------------------------------
	// Libero variables auxiliares
	delete[] values;
	delete[] messages;
	delete[] errors;
	for (int i = 0; i < GameConfig::PARAMETER_COUNT; i++)
	{
		delete[] limits[i];
	}
	delete[] limits;
	// ----------------------------------------------

	return gameConfig;
}

void Screen::printInstructions(const GameConfig *gameConfig) const
{
	logger().writeLine();
	logger().writeLine("=====================================");
	logger().writeLine("\tINSTRUCCIONES");
	logger().writeLine("=====================================");
	logger().writeLine();
	logger() << "* El tablero tiene dimensión "
			 << gameConfig->getBoardRowCount() << " x "
			 << gameConfig->getBoardColumnCount() << " x "
			 << gameConfig->getBoardLevelCount() << "." << endl;
	logger() << "* El tablero esta compuesto por celdas y cada celda tiene un terrono específico (tierra/agua/aire)." << endl;
	logger() << "* Hay " << gameConfig->getCommanderCount() << " jugadores que batallan entre sí." << endl;
	logger() << "* Cada jugador dispone inicialmente de:" << endl;
	logger() << "\t- Soldados: " << gameConfig->getCommanderSoldiersCount() << " unidades." << endl;
	logger() << "\t- Aviones (armamento): " << gameConfig->getCommanderAircraftCount() << " unidades." << endl;
	logger() << "\t- Barcos (armamento): " << gameConfig->getCommanderWarshipsCount() << " unidades." << endl;
	logger().writeLine("* En cada turno el jugador deja una mina en un casillero:");
	logger().writeLine("\t- El casillero queda minado si está vacío.");
	logger().writeLine("\t- Si el casillero tiene un soldado o armamento enemigo la mina explota");
	logger().writeLine("\t  destruyéndolo y dejando el casillero inactivo por algunos turnos en función del poder de la mina.");
	logger().writeLine("\t- No se puede dejar una mina si hay un soldado o armamento propio o si el casillero ");
	logger().writeLine("\t  esta inactivo.");
	logger().writeLine("\t- Si hay una mina del contrincante ésta será reemplazada por una mina propia.");
	logger().writeLine("* Luego de lanzar una mina el jugador puede mover un soldado o armamento un casillero alrededor:");
	logger().writeLine("\t- Si el casillero está ocupado por un soldado o armamento enemigo ambos se destruyen.");
	logger().writeLine("\t- No se puede mover a una casilla desactivada.");
	logger().writeLine("* Previo a finalizar su turno el jugador toma una carta del mazo y puede optar por jugarla o acumularla.");
	logger().writeLine("\t- Las cartas pueden acumularse y jugarse en turnos posteriores.");
	logger().writeLine("\t- Las cartas poseen poderes especiales que pueden aplicarse sobre soldados, armamentos o directamente sobre el campo.");
	logger().writeLine("* El jugador que se queda sin soldados y armammento queda fuera de juego.");
	logger().writeLine("* El jugador que sobrevive será el ganador");
	logger().writeLine();
}

void Screen::printTurnStart(int turn, Commander *commander) const
{
	logger().writeLine();
	logger() << ">> Turno " << turn << ": "
			 << commander->getName()
			 << " a combatir !!";
	logger().writeLine();
	logger() << "- Soldados: " << setw(8) << commander->getMilitaryUnitsCount<Soldier>() << endl;
	logger() << "- Aviones: " << setw(9) << commander->getMilitaryUnitsCount<Airship>() << endl;
	logger() << "- Buques: " << setw(10) << commander->getMilitaryUnitsCount<Warship>() << endl;
	logger() << "- Cartas: " << setw(10) << commander->getEnabledCardsCount() << endl;
	logger().writeLine();
}

void Screen::printGameEnd(Commander *winner) const
{
	logger().writeLine();
	logger().writeLine();
	logger().writeLine("=====================================");
	logger().writeLine("Juego terminado!!!");
	logger().writeLine();
	logger() << "** " << winner->getName() << " ** es el ganador" << endl;
	logger().writeLine();
	logger() << "- Soldados: " << setw(8) << winner->getMilitaryUnitsCount<Soldier>() << endl;
	logger() << "- Aviones: " << setw(9) << winner->getMilitaryUnitsCount<Airship>() << endl;
	logger() << "- Buques: " << setw(10) << winner->getMilitaryUnitsCount<Warship>() << endl;
	logger() << "- Cartas restantes:" << setw(10) << winner->getEnabledCardsCount() << endl;
	logger().writeLine("=====================================");
}

struct MoveCommand
{
	int key;
	RelativePosition rPos;
	string icon;
};

void Screen::printBoard(Board *board, Commander *currentCommander) const
{
	BMP *canvas = new BMP();
	canvas->SetSize(CANVAS_WIDTH, CANVAS_HEIGHT);
	canvas->SetBitDepth(COLOR_BIT_DEPTH);

	// ---------------------------------------
	// Se imprime el fondo
	// ---------------------------------------
	string path = this->assetMap.at(getBackgroundLabel())->getPath();
	canvas->ReadFromFile(path.c_str());

	drawNumber(currentCommander->getNumber(), PLAYER_NUMBER_LABEL_X, PLAYER_NUMBER_LABEL_Y, canvas);
	drawNumber(currentCommander->getEnabledCardsCount(), PLAYER_CARD_LABEL_X, PLAYER_CARD_LABEL_Y, canvas);

	// ---------------------------------------
	// Recorrido del tablero
	// ---------------------------------------
	Camera camera;
	camera.position.x = -0.5 * board->getSize().rowCount;
	camera.position.y = -2.0 / 3 * board->getSize().columnCount;
	camera.position.z = 0.6 * board->getSize().levelCount;
	camera.angleX = 0.5 * PI;
	camera.angleY = 0.7267 * PI;

	CellCube *cellCube = board->getCellCube();

	// Se recorre el cubo de celdas para imprimir TERRENOS
	cellCube->resetCursor();
	while (cellCube->advanceCursor())
	{
		CellLevel *cellLevel = cellCube->getCursor();

		cellLevel->resetCursor();
		while (cellLevel->advanceCursor())
		{
			CellRow *cellRow = cellLevel->getCursor();

			cellRow->resetCursor();
			while (cellRow->advanceCursor())
			{
				Cell *cell = cellRow->getCursor();
				drawCellTerrain(*cell, camera, canvas);
			}
		}
	}

	// Se recorre el cubo de celdas para imprimir ESTADOS y FICHAS
	cellCube->resetCursor();
	while (cellCube->advanceCursor())
	{
		CellLevel *cellLevel = cellCube->getCursor();

		cellLevel->resetCursor();
		while (cellLevel->advanceCursor())
		{
			CellRow *cellRow = cellLevel->getCursor();

			cellRow->resetCursor();
			while (cellRow->advanceCursor())
			{
				Cell *cell = cellRow->getCursor();
				drawCellStatus(*cell, camera, canvas);
				drawCellBoardToken(*cell, camera, canvas, currentCommander);
			}
		}
	}

	canvas->WriteToFile("output/board.bmp");
	delete canvas;
}

void Screen::drawNumber(int number, int x, int y, BMP *canvas) const
{
	stringstream ss;
	ss << setw(NUMBER_LENGTH) << setfill('0') << number << endl;
	const char *digits = ss.str().c_str();

	string path = this->assetMap.at(getcharsetLabel())->getPath();

	BMP *charset = new BMP();
	charset->ReadFromFile(path.c_str());

	for (int i = 0; i < NUMBER_LENGTH; i++)
	{
		int digit = digits[i] - '0';

		RangedPixelToPixelCopy(
			*charset,
			digit * CHAR_WIDTH, (digit + 1) * CHAR_WIDTH - 1, charset->TellHeight() - 1, 0,
			*canvas, x, y);

		x += CHAR_WIDTH;
	}
	delete charset;
}

void Screen::drawCellTerrain(const Cell &cell, const Camera camera, BMP *canvas) const
{
	stringstream ss;
	ss << getTerrainLabel() << cell.getTerrain();

	string path = this->assetMap.at(ss.str())->getPath();
	ss.str("");

	Position cellPosition = cell.getPosition();
	Position proyectedPos = getProyectedPositionViewedFromCamera(cellPosition, camera);

	BMP *cellBackground = new BMP();
	cellBackground->ReadFromFile(path.c_str());

	Position assetPosition = {proyectedPos.x, canvas->TellHeight() - 1 - proyectedPos.y};
	RangedPixelToPixelCopy(
		*cellBackground,
		0, cellBackground->TellWidth() - 1, cellBackground->TellHeight() - 1, 0,
		*canvas, assetPosition.x, assetPosition.y);

	delete cellBackground;
}

RGBApixel Screen::getTransparentBackground() const
{
	RGBApixel bg;
	bg.Red = 255;
	bg.Green = 0;
	bg.Blue = 220;
	return bg;
}

bool Screen::isPrintableCellStatus(CellStatus status) const
{
	return status == DEACTIVATED || status == MARKED;
}

void Screen::drawCellStatus(const Cell &cell, const Camera camera, BMP *canvas) const
{
	stringstream ss;
	CellStatus status = cell.getStatus();

	if (isPrintableCellStatus(status))
	{
		ss << getCellStatusLabel() << status;
		string assetPath = this->assetMap.at(ss.str())->getPath();
		ss.str("");

		BMP *cellStatusView = new BMP();
		RGBApixel bg = getTransparentBackground();

		cellStatusView->ReadFromFile(assetPath.c_str());

		Position proyectedPos = getProyectedPositionViewedFromCamera(cell.getPosition(), camera);
		Position assetPosition = {proyectedPos.x, canvas->TellHeight() - 1 - proyectedPos.y};

		RangedPixelToPixelCopyTransparent(
			*cellStatusView,
			0, cellStatusView->TellWidth() - 1, cellStatusView->TellHeight() - 1, 0,
			*canvas, assetPosition.x, assetPosition.y, bg);

		delete cellStatusView;
	}
}

void Screen::drawCellBoardToken(const Cell &cell, const Camera camera, BMP *canvas, Commander *currentCommander) const
{
	BoardToken *token = cell.getLinkedBoardToken();

	Soldier *soldier = dynamic_cast<Soldier *>(token);
	Mine *mine = dynamic_cast<Mine *>(token);
	Airship *airship = dynamic_cast<Airship *>(token);
	Warship *warship = dynamic_cast<Warship *>(token);

	Asset *asset = NULL;
	if (soldier != NULL)
	{
		asset = this->assetMap.at(typeid(Soldier).name());
	}
	else if (mine != NULL)
	{
		asset = this->assetMap.at(typeid(Mine).name());
	}
	else if (airship != NULL)
	{
		asset = this->assetMap.at(typeid(Airship).name());
	}
	else if (warship != NULL)
	{
		asset = this->assetMap.at(typeid(Warship).name());
	}

	// Si la celda contiene algo lo imprimo
	if (asset != NULL && token->getOwner()->getNumber() == currentCommander->getNumber())
	{
		BMP *cellContent = new BMP();
		RGBApixel bg = getTransparentBackground();

		cellContent->ReadFromFile(asset->getPath().c_str());

		Position proyectedPos = getProyectedPositionViewedFromCamera(cell.getPosition(), camera);
		Position assetPosition = {proyectedPos.x, canvas->TellHeight() - 1 - proyectedPos.y};

		RangedPixelToPixelCopyTransparent(
			*cellContent,
			0, cellContent->TellWidth() - 1, cellContent->TellHeight() - 1, 0,
			*canvas, assetPosition.x, assetPosition.y, bg);

		delete cellContent;
	}
}

Position Screen::getProyectedPositionViewedFromCamera(Position pos, Camera camera) const
{
	Position proyectedPos;
	double pcx, pcy, pcz;

	// Matriz de rotación normal a X, plano YZ
	// Rx(a): [1 0 0; 0 cos(a) -sin(a); 0 sin(a) cos(a)]
	//
	// Matriz de rotación normal a Y, plano XZ
	// Ry(b): [cos(b) 0 sin(b); 0 1 0; -sin(b) 0 cos(b)]
	//
	// Matriz de rotación total
	// Primero se rota en normal a X y luego normal a Y
	// R = Ry(b) * Rx(a)
	//
	// Posición vista desde la cámara
	// vr = R * (pos-camera.position);

	// Coordenadas vistas desde la cámara
	pcx = (pos.x - camera.position.x) * cos(camera.angleY) + (pos.z - camera.position.z) * cos(camera.angleX) * sin(camera.angleY) + (pos.y - camera.position.y) * sin(camera.angleX) * sin(camera.angleY);
	pcy = (pos.y - camera.position.y) * cos(camera.angleX) - (pos.z - camera.position.z) * sin(camera.angleX);
	pcz = (pos.z - camera.position.z) * cos(camera.angleX) * cos(camera.angleY) - (pos.x - camera.position.x) * sin(camera.angleY) + (pos.y - camera.position.y) * cos(camera.angleY) * sin(camera.angleX);

	// Coordenadas proyectadas a f unidades del eje óptico de la cámara
	double f = 0.75 * CANVAS_WIDTH;
	proyectedPos.x = f * pcx / pcz;
	proyectedPos.y = f * pcy / pcz;
	proyectedPos.z = f;

	// Correción por desplazamiento
	proyectedPos.x += 0.61 * CANVAS_WIDTH;
	proyectedPos.y += 0.61 * CANVAS_HEIGHT;

	return proyectedPos;
}
