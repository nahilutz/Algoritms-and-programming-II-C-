/*
 * screen.h
 */

#ifndef SCREEN_SCREEN_H_
#define SCREEN_SCREEN_H_

#include <iostream>

#include <cmath>
#include <map>
#include <typeinfo>
#include <iomanip>
#include <sstream>

#include "easy-bmp/EasyBMP.h"
#include "asset/asset.h"

#include "../logger/logger.h"

#include "../core/core.h"

#include "../board-game/commander/commander.h"
#include "../board-game/game-config/game-config.h"
#include "../core/board/board.h"
#include "../core/mine/mine.h"

typedef std::map<std::string, Asset *> AssetMap;

struct Camera
{
	Position position;
	double angleX;
	double angleY;
};

class Screen
{
public:
	/*
	 * PRE: -
	 * POS: Obtiene la única instancia disponible de la pantalla (Singleton pattern).
	 */
	static Screen &getInstance()
	{
		static Screen instance;
		return instance;
	}
	/*
	 * PRE: -
	 * POS: Destruye la pantalla y libera recursos.
	 */
	virtual ~Screen();
	/*
	 * PRE: -
	 * POS: Devuelve le logger de la pantalla.
	 */
	static Logger &getLogger()
	{
		return logger();
	}

private:
	/*
	 * PRE: -
	 * POS: Obtiene la unica instancia disponible del logger (Singleton pattern).
	 */
	static Logger &logger()
	{
		return Logger::getInstance();
	}

	/*
	 * Manejo de pantalla e input del usuario
	 *
	 */

private:
	AssetMap assetMap;

	static const int COLOR_BIT_DEPTH = 24;

	static const int CANVAS_WIDTH = 1920;
	static const int CANVAS_HEIGHT = 1920;

	static const int CHAR_WIDTH = 100;
	static const int NUMBER_LENGTH = 3;

	static const int PLAYER_NUMBER_LABEL_X = 720;
	static const int PLAYER_NUMBER_LABEL_Y = 35;

	static const int PLAYER_CARD_LABEL_X = CANVAS_WIDTH - NUMBER_LENGTH * CHAR_WIDTH - 10;
	static const int PLAYER_CARD_LABEL_Y = PLAYER_NUMBER_LABEL_Y;

private:
	/*
	 * PRE: -
	 * POS: Crea una instancia de la pantalla.
	 */
	Screen();
	/*
	 * PRE: -
	 * POS: Devuelve la etiqueta utilizada para los assets de terreno.
	 */
	std::string getTerrainLabel() const;
	/*
	 * PRE: -
	 * POS: Devuelve la etiqueta utilizada para los assets de estado de celda.
	 */
	std::string getCellStatusLabel() const;
	/*
	 * PRE: -
	 * POS: Devuelve la etiqueta utilizada para el asset del fondo.
	 */
	std::string getBackgroundLabel() const;
	/*
	 * PRE: -
	 * POS: Devuelve la etiqueta utilizada para el asset del charset.
	 */
	std::string getcharsetLabel() const;

public:
	/*
	 * PRE: -
	 * POS: Lee un valor genérico T por consola.
	 */
	template <typename T>
	T readValue() const
	{
		T value;
		std::cin >> value;
		return value;
	}
	/*
	 * PRE: -
	 * POS: Imprime las instrucciones del juego.
	 */
	void printInstructions(const GameConfig *gameConfig) const;
	/*
	 * PRE: -
	 * POS: Imprime el título del juego.
	 */
	void printTitle() const;
	/*
	 * PRE: -
	 * POS: Pide al usuario ingresar la configuración del juego. Devuelve un nuevo objeto con la configuración del juego.
	 */
	GameConfig *startGameConfigDialog() const;
	/*
	 * PRE: El turno debe ser mayor a cero. El comandante debe ser no nulo.
	 * POS: Imprime el turno actual del juego.
	 */
	void printTurnStart(int turn, Commander *commander) const;
	/*
	 * PRE: El jugador debe ser no nulo.
	 * POS: Imprime el resultado final del juego.
	 */
	void printGameEnd(Commander *winner) const;

	/*
	 * Visualización del tablero
	 *
	 */
private:
	/*
	 * PRE: El canvas y el comandante actual deben ser no nulos.
	 * POS: Dibuja un número en el canvas.
	 */
	void drawNumber(int number, int x, int y, BMP *canvas) const;
	/*
	 * PRE: -
	 * POS: Devuelve la posición vista desde la cámara proyectada en un plano.
	 */
	Position getProyectedPositionViewedFromCamera(Position pos, Camera camera) const;
	/*
	 * PRE: El canvas debe ser no nulo.
	 * POS: Dibuja el terreno de la celda en el canvas.
	 */
	void drawCellTerrain(const Cell &cell, const Camera camera, BMP *canvas) const;
	/*
	 * PRE: El canvas debe ser no nulo.
	 * POS: Dibuja es estado de la celda en el canvas.
	 */
	void drawCellStatus(const Cell &cell, const Camera camera, BMP *canvas) const;
	/*
	 * PRE: -
	 * POS: Verifica si un estado de la celda se puede imprimir o no.
	 */
	bool isPrintableCellStatus(CellStatus status) const;
	/*
	 * PRE: El canvas y el comandante actual deben ser no nulos.
	 * POS: Dibuja la ficha de la celda.
	 */
	void drawCellBoardToken(const Cell &cell, const Camera camera, BMP *canvas, Commander *currentCommander) const;
	/*
	 * PRE: -
	 * POS: Devuelve el color del fondo transparente de los assets.
	 * 		Este color es ignorado al imprimir assets con transparencia.
	 */
	RGBApixel getTransparentBackground() const;
	/*
	 * PRE: -
	 * POS: Muestra los assets contenidos en el diccionario (debugging).
	 */
	void displayAssetMap();

public:
	/*
	 * PRE: El tablero y el comandante deben ser no nulos.
	 * POS: Imprime el tablero del juego en el turno dado.
	 */
	void printBoard(Board *board, Commander *currentCommander) const;
};
#endif /* SCREEN_SCREEN_H_ */
