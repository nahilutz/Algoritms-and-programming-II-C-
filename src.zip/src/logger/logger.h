/*
 * Logger.h
 */

#ifndef LOGGER_LOGGER_H_
#define LOGGER_LOGGER_H_

#include "../core/core.h"

#include <sstream>

class Logger
{
private:
	/*
	 * PRE: -
	 * POS: Crea una instancia de la clase.
	 */
	Logger();

public:
	/*
	 * PRE: -
	 * POS: Obtiene la única instancia disponible del logger (Singleton pattern).
	 */
	static Logger &getInstance()
	{
		static Logger instance;
		return instance;
	}
	/*
	 * PRE: -
	 * POS: Destruye una instancia de la clase y libera recursos.
	 */
	virtual ~Logger();
	/*
	 * PRE: -
	 * POS: Imprime por pantalla el string.
	 */
	std::ostream &write(const std::string str) const;
	/*
	 * PRE: -
	 * POS: Imprime por pantalla el string y produce un salto de línea.
	 */
	void writeLine(const std::string str) const;
	/*
	 * PRE: -
	 * POS: Produce un salto de línea por pantalla.
	 */
	void writeLine() const;
	/*
	 * PRE: -
	 * POS: Escribe una línea mediante el operador '<<'. (logger << "Hola: " << 10)
	 */
	template <typename T>
	friend std::ostream &operator<<(const Logger &logger, const T &obj)
	{
		std::stringstream ss;
		ss << obj;
		return logger.write(ss.str());
	}
};

#endif /* LOGGER_LOGGER_H_ */
