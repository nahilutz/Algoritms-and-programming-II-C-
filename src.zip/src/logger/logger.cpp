/*
 * Logger.cpp
 */

#include "logger.h"

using namespace std;

Logger::Logger()
{
}

Logger::~Logger()
{
}

ostream &Logger::write(const string str) const
{
	return cout << str;
}

void Logger::writeLine(const string str) const
{
	this->write(str) << endl;
}

void Logger::writeLine() const
{
	this->writeLine("");
}
