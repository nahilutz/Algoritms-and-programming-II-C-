/*
 * commander.cpp
 *
 */

#include "commander.h"

Commander::Commander(int number) : Player(number)
{
	this->subordinates = new SubordinateList();
	this->cards = new CardList();
}

Commander::~Commander()
{
	// Elimino subordinados
	subordinates->resetCursor();
	while (subordinates->advanceCursor())
	{
		delete subordinates->getCursor();
	}
	delete subordinates;

	// Elimino cartas
	cards->resetCursor();
	while (cards->advanceCursor())
	{
		delete cards->getCursor();
	}
	delete cards;
}

void Commander::addSubordinate(Subordinate *subordinate)
{
	subordinates->append(subordinate);
}

void Commander::addCard(Card *card)
{
	cards->append(card);
}

SubordinateList *Commander::getActiveSubordinates() const
{
	SubordinateList *activeSubordinates = new SubordinateList();

	subordinates->resetCursor();
	while (subordinates->advanceCursor())
	{
		Subordinate *subordinate = subordinates->getCursor();
		if (subordinate->isActive())
		{
			activeSubordinates->append(subordinate);
		}
	}
	return activeSubordinates;
}

CardList *Commander::getEnabledCards() const
{
	CardList *enabledCards = new CardList();

	cards->resetCursor();
	while (cards->advanceCursor())
	{
		Card *card = cards->getCursor();
		if (card->isEnabled())
		{
			enabledCards->append(card);
		}
	}
	return enabledCards;
}

int Commander::getEnabledCardsCount() const
{
	int enabledCardsCount = 0;

	cards->resetCursor();
	while (cards->advanceCursor())
	{
		Card *card = cards->getCursor();
		if (card->isEnabled())
		{
			enabledCardsCount++;
		}
	}
	return enabledCardsCount;
}

void Commander::activateCard(int cardNumber)
{
	this->getEnabledCards()->get(cardNumber)->activateCard();
}

bool Commander::isActive() const
{
	return getMilitaryUnitsCount<Subordinate>() > 0;
}
