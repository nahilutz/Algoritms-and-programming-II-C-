/*
 * commander.h
 *
 */

#ifndef BOARD_GAME_COMMANDER_COMMANDER_H_
#define BOARD_GAME_COMMANDER_COMMANDER_H_

#include "../../core/structure/list.h"

#include "../../core/player/player.h"

#include "../../core/board-token/board-token.h"
#include "../../core/soldier/soldier.h"
#include "../../core/airship/airship.h"
#include "../../core/warship/warship.h"
#include "../../core/card/card.h"

typedef BoardToken Subordinate;
typedef List<Subordinate *> SubordinateList;
typedef List<Soldier *> SoldierList;
typedef List<Airship *> AirshipList;
typedef List<Warship *> WarshipList;
typedef List<Card *> CardList;

class Commander : public Player
{
private:
	SubordinateList *subordinates;
	CardList *cards;

public:
	/*
	 * PRE: El numero del comandante debe ser mayor a cero.
	 * POS: Crea una instancia del comandante dado su número.
	 */
	Commander(int number);
	/*
	 * PRE: -
	 * POS: Destruye al comandante y libera recursos.
	 */
	virtual ~Commander();
	/*
	 * PRE: La ficha debe ser no nula.
	 * POS: Agrega un subordinado (ficha) al comandante.
	 */
	void addSubordinate(Subordinate *subordinate);
	/*
	 * PRE: La carta debe ser no nula.
	 * POS: Agrega una carta al comandante.
	 */
	void addCard(Card *card);
	/*
	 * PRE: -
	 * POS: Devuelve un nueva lista de subordinados (fichas) activas que posee el comandante
	 */
	SubordinateList *getActiveSubordinates() const;
	/*
	 * PRE: -
	 * POS: Devuelve un nueva lista de las cartas habilitadas que posee el comandante
	 */
	CardList *getEnabledCards() const;
	/*
	 * PRE: -
	 * POS: Devuelve la cantidad de cartas habilitadas que tiene el comandante.
	 */
	int getEnabledCardsCount() const;
	/*
	 * PRE: -
	 * POS: Devuelve una nueva lista de unidades militares T activas que posee el comandante.
	 */
	template <typename T>
	List<T *> *getMilitaryUnits() const
	{
		List<T *> *units = new List<T *>();

		subordinates->resetCursor();
		while (subordinates->advanceCursor())
		{
			Subordinate *subordinate = subordinates->getCursor();
			T *unit = dynamic_cast<T *>(subordinate);

			if (unit != NULL && subordinate->isActive())
			{
				units->append(unit);
			}
		}

		return units;
	}
	/*
	 * PRE: -
	 * POS: Devuelve la cantidad de unidades militares T activas que posee el comandante.
	 */
	template <typename T>
	int getMilitaryUnitsCount() const
	{
		int unitCount = 0;

		subordinates->resetCursor();
		while (subordinates->advanceCursor())
		{
			Subordinate *subordinate = subordinates->getCursor();
			T *unit = dynamic_cast<T *>(subordinate);

			if (unit != NULL && subordinate->isActive())
			{
				unitCount++;
			}
		}
		return unitCount;
	}
	/*
	 * PRE: El número de la carte tiene que ser mayor cero.
	 * POS: Activa una carta del comandante
	 */
	void activateCard(int cardNumber);
	/*
	 * PRE: -
	 * POS: Determina si el comandante esta activo o no.
	 */
	bool isActive() const;
};

#endif /* BOARD_GAME_COMMANDER_COMMANDER_H_ */
