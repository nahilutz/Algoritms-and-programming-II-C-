/*
 * board-game.h
 *
 */

#ifndef BOARD_GAME_BOARD_GAME_H_
#define BOARD_GAME_BOARD_GAME_H_

#include <typeinfo>
#include <algorithm>

#include "../core/core.h"
#include "game-config/game-config.h"

#include "../core/board/board.h"
#include "commander/commander.h"

#include "../core/soldier/soldier.h"
#include "../core/mine/mine.h"
#include "../core/airship/airship.h"
#include "../core/warship/warship.h"

#include "../board-game/deck/deck.h"

#include "../screen/screen.h"

struct GameStatus
{
	bool hasWinner;
	Commander *winner;
};

typedef List<Commander *> CommanderList;
typedef BoardSize Region;

typedef std::map<std::string, std::string> BoardTokenNameMap;

static const int HORIZONT_HEIGHT = 5;

static const int MAX_RIVER_LENGTH = 50;
static const int MIN_RIVER_LENGTH = 3;
static const int MAX_RIVER_WIDTH = 4;
static const int MIN_RIVER_WIDTH = 3;
static const int RIVER_DEPTH = 4;

static const int MAX_LAKE_RADIUS = 15;
static const int MIN_LAKE_RADIUS = 3;
static const int MAX_LAKE_DEPTH = 4;
static const int MIN_LAKE_DEPTH = 2;

static const int RIVER_COUNT = 3;
static const int LAKE_COUNT = 2;

static const int BOARD_DIMENSION_PERCENT = 20;

class Deck;
class BoardGame
{
private:
	GameConfig *gameConfig;
	Board *board;
	CommanderList *commanders;
	Commander *currentCommander;
	Deck *deck;

	BoardTokenNameMap tokenNameMap;

private:
	/*
	 * PRE: -
	 * POS: Crea el tablero, inicializa los terrenos, crea los jugadores con sus soldados y armamentos
	 * 		dispuestos de manera aleatoria en el tablero.
	 */
	void initialize();
	/*
	 * PRE: -
	 * POS: Define el terreno que le corresponde a la celda según la altura del horizonte. por debajo del horizonte será
	 * 		todo tierra. Por encima será todo aire.
	 */
	CellTerrain defineCellTerrain(const Cell &cell) const;
	/*
	 * PRE: La lista de posiciones no debe ser nula.
	 * POS: Genera una posición aleatoria dentro del tablero que no esté entre de las posiciones no disponibles.
	 */
	Position generateRandomUniquePosition(PositionList *notAvailablePositions, BoardSize size) const;
	/*
	 * PRE: La lista de posiciones no debe ser nula.
	 * POS: Genera una posición aleatoria dentro del tablero que no esté entre de las posiciones no disponibles.
	 * 		La posición generada pude tener un cierto offset.
	 */
	Position generateRandomUniquePosition(PositionList *notAvailablePositions, BoardSize size, Position offset) const;
	/*
	 * PRE: El commandante y la lista de posiciones deben ser no nulos
	 * POS: Genera los soldados del comandante ubicados en posiciones que no esten presentes en la lista de posiciones.
	 * 		Luego los vincula al comandante.
	 */
	void generateCommanderSoldiers(Commander *commander, PositionList *notAvailablePositions);
	/*
	 * PRE: El commandante y la lista de posiciones deben ser no nulos
	 * POS: Genera los aviones del comandante ubicados en posiciones que no esten presentes en la lista de posiciones.
	 * 		Luego los vincula al comandante.
	 */
	void generateCommanderAirships(Commander *commander, PositionList *notAvailablePositions);
	/*
	 * PRE: El commandante y la lista de posiciones deben ser no nulos
	 * POS: Genera los buques del comandante ubicados en posiciones que no esten presentes en la lista de posiciones.
	 * 		Luego los vincula al comandante.
	 */
	void generateCommanderWarships(Commander *commander, PositionList *notAvailablePositions);
	/*
	 * PRE: -
	 * POS: Verifica el estado del juego, si hay algún jugador que haya ganado o no.
	 */
	GameStatus checkGameStatus();
	/*
	 * PRE: El numero del comandante deber mayor a cero.
	 * POS: Obtiene el comandante dado su número. Devuelve NULL si no lo encuentra.
	 */
	Commander *getCommanderByNumber(int number);
	/*
	 * PRE: -
	 * POS: Actualiza el time de las celdas desactivas.
	 */
	void updateCellsTimer();
	/*
	 * PRE: El comandante deben ser no nulos
	 * POS: Comienza el diálogo de lazado de mina.
	 */
	void startDropMineDialog(Commander *commander);
	/*
	 * PRE: El comandante debe ser no nulo
	 * POS: Lanza una mina de un commandante en una posición dada.
	 */
	void dropMineAt(Position position, Commander *owner);
	void startCardActionDialog(Commander *commander);
	void displayCards(CardList *cardsInHand);
	/*
	 * PRE: El comandante debe ser no nulo
	 * POS: Comienza el dialogo para mover un soldado o armamento
	 */
	void startMoveSoldierDialog(Commander *commander);
	/*
	 * PRE: El comandante debe ser no nulo
	 * POS: Devuelve un nuevo vector con las posiciones disponibles para mover una unidad.
	 */
	RelativePositionList *getAvailablePositionsForMovingAt(Position position, Commander *owner);
	/*
	 * PRE: La lists de posiciones debe ser no nula
	 * POS: Muesta por pantalla la lista de posiciones relativas.
	 */
	void displayedRelativePositions(RelativePositionList *positions) const;

private:
	/*
	 * PRE: -
	 * POS: Valida el número del comandante.
	 */
	void validateCommanderNumber(int number);
	/*
	 * PRE: La posición debe ser válida dentro del tablero.
	 * POS: Verifica si en la posición dada una unidad militar
	 */
	bool cellHasMilitaryUnit(Position position) const;
	/*
	 * PRE: La ficha debe ser no nula.
	 * POS: Devuelve el nombre a mostrar de la ficha.
	 */
	std::string getTokenDisplayName(BoardToken *token) const;
	/*
	 * PRE: -
	 * POS: Estable el comandante del turno actual.
	 */
	void setCurrentCommander(Commander *commander);

public:
	/*
	 * PRE: -
	 * POS: Pide al usuario ingresar la configuración del juego. Devuelve un nuevo objeto con la configuración del juego.
	 */
	static GameConfig *startGameConfigDialog();
	/*
	 * PRE: La configuración del juego debe ser no nula.
	 * POS: Crea una instancia de Batalla Digital
	 */
	BoardGame(GameConfig *gameConfig);
	/*
	 * PRE: -
	 * POS: Destruye Batalla Digital y libera recursos.
	 */
	virtual ~BoardGame();
	/*
	 * PRE: -
	 * POS: Devuelve la configuración del juego Batalla Digital.
	 */
	GameConfig *getGameConfig() const;
	/*
	 * PRE: -
	 * POS: Devuelve el tablero del juego Batalla Digital.
	 */
	Board *getBoard() const;
	/*
	 * PRE: -
	 * POS: Comienza el juego Batalla Digital.
	 */
	void start();
	/*
	 * PRE: -
	 * POS: Devuelve el tablero del juego
	 */
	Board *getGameBoard() const;
	/*
	 * PRE: -
	 * POS: Valida que en el la posición dada se pueda tirar una mina.
	 * 		Actualiza error con el mensaje si lo hubiere.
	 */
	bool validateMineDropPosition(Position position, Commander *commander, std::string &error) const;
	/*
	 * PRE: La posición debe estar dentro del tablero.
	 * POS: Marca la celda si esta desmarcada o la desmarca si esta marcada. Se guarda el estado anterior de la celda.
	 */
	void toggleCellMark(Position position);
	/*
	 * PRE: -
	 * POS: With a random width, length and depth, generates a River
	 */
	void generateRiver();
	/*
	 * PRE: -
	 * POS: With a random radius and depth, generates a Lake
	 */
	void generateLake();
	/*
	 * PRE: -
	 * POS: Switches the 'Terrain' attribute of the cell to WATER
	 * @param bodyOfWaterLength, bodyOfWaterWidth, bodyOfWaterDepth: River or Lake measurements
	 */
	void generateWaterBody(int waterBodyLength, int waterBodyWidth, int waterBodyDepth);
	/*
	 * PRE: -
	 * POS: Mueve un soldado o armamento a un posición relativa dada.
	 */
	void moveMilitaryUnit(RelativePosition position);
	/*
	 * PRE: La ficha debe ser no nula.
	 * POS: Intenta explotar una mina en una celda si la hubiese. La ficha que aterriza a esa celda muera.
	 */
	bool explodeMineAt(Position position, BoardToken *landingToken);
	/*
	 * PRE: -
	 * POS: Devuelve el comandente del turno actual.
	 */
	Commander *getCurrentCommander() const;
	/*
	 * PRE: -
	 * POS: Verifica si en la posición dada hay una ficha del tipo T.
	 */
	template <typename T>
	bool cellHasToken(Position position) const
	{
		if (!board->isValidPosition(position))
		{
			throw "La casilla no existe en la posición dada";
		}
		Cell *cell = board->getCell(position);
		return cellHasToken<T>(cell);
	}
	/*
	 * PRE: -
	 * POS: Verifica si en la celdas dada hay una ficha del tipo T.
	 */
	template <typename T>
	bool cellHasToken(Cell *cell) const
	{
		BoardToken *token = cell->getLinkedBoardToken();
		return token != NULL && dynamic_cast<T *>(token);
	}
	/*
	 * PRE: El comandante debe ser no nulo
	 * POS: Verifica si en la posición dada hay una ficha propia del tipo T.
	 */
	template <typename T>
	bool cellHasOwnToken(Position position, Commander *owner) const
	{
		if (!board->isValidPosition(position))
		{
			throw "La casilla no existe en la posición dada";
		}
		if (owner == NULL)
		{
			throw "El comandante debe ser no nulo";
		}
		BoardToken *token = board->getCell(position)->getLinkedBoardToken();
		return token != NULL && dynamic_cast<T *>(token) && token->getOwner()->getNumber() == owner->getNumber();
	}
	/*
	 * PRE: La lista de subordinados debe ser no nula.
	 * 		El tipo T debe ser un subordinado.
	 * POS: Muesta por pantalla la lista de subordinados.
	 */
	template <typename T>
	void displayedSubordinates(List<T> *subordinates) const
	{
		if (subordinates == NULL)
		{
			throw "La lista de subordinados debe ser no nula";
		}

		int number = 1;
		subordinates->resetCursor();
		while (subordinates->advanceCursor())
		{
			Subordinate *subordinate = subordinates->getCursor();
			Position position = subordinate->getPosition();

			screen().getLogger() << number << ". " << getTokenDisplayName(subordinate)
								 << " (" << position.x + 1 << "," << position.y + 1 << "," << position.z + 1 << ")"
								 << std::endl;
			number++;
		}
	}

private:
	/*
	 * PRE: -
	 * POS: Acceso a la pantalla (Sigleton Pattern)
	 */
	static Screen &screen()
	{
		return Screen::getInstance();
	}

public:
	static Screen &getScreen()
	{
		return screen();
	}
};

#endif /* BOARD_GAME_BOARD_GAME_H_ */
