/*
 * field-detector.cpp
 */

#include "field-detector.h"

using namespace std;

FieldDetector::FieldDetector(BoardGame *boardGame) : Power(DURATION, RANGE)
{
	this->name = "Detectar Terreno";
	this->boardGame = boardGame;
	this->setDamageRange(getDamageRange());
}

FieldDetector::~FieldDetector()
{
}

// pre: -
// pos: Detect in the range of the selected position the objects around
void FieldDetector::activatePower()
{
	Position pos;
	bool invalidPosition = true;

	boardGame->getScreen().getLogger().writeLine();
	boardGame->getScreen().getLogger() << this->name << ": Seleccioná una posicion del tablero para analizar el terreno" << endl;

	// while the selected field is not a valid fiel position in the board, the player must re select the position
	while (invalidPosition)
	{
		boardGame->getScreen().getLogger() << "Fila: ";
		pos.y = boardGame->getScreen().readValue<int>() - 1;

		boardGame->getScreen().getLogger() << "Columna: ";
		pos.x = boardGame->getScreen().readValue<int>() - 1;

		boardGame->getScreen().getLogger() << "Nivel: ";
		pos.z = boardGame->getScreen().readValue<int>() - 1;

		if (this->boardGame->getBoard()->isValidPosition(pos))
		{
			invalidPosition = false;
		}
		else
		{
			boardGame->getScreen().getLogger() << "Ingresá una posicion dentro de las dimensiones del tablero y verificá que sea un soldado." << endl;
		}
	}
	boardGame->getScreen().getLogger().writeLine();

	BoardSize boardSize = boardGame->getBoard()->getSize();

	// percentage range
	int range = this->getDamageRange();

	// Calcular los límites del rango de verificación
	int xMin = max(0, pos.x - range);
	int xMax = min(boardSize.columnCount - 1, pos.x + range);

	int yMin = max(0, pos.y - range);
	int yMax = min(boardSize.rowCount - 1, pos.y + range);

	int zMin = max(0, pos.z - range);
	int zMax = min(boardSize.levelCount - 1, pos.z + range);

	// verification of cells around the position selected
	for (int i = xMin; i <= xMax; ++i)
	{
		for (int j = yMin; j <= yMax; ++j)
		{
			for (int k = zMin; k <= zMax; ++k)
			{
				Position currentPosition;
				currentPosition.x = i;
				currentPosition.y = j;
				currentPosition.z = k;

				Cell *cell = this->boardGame->getBoard()->getCell(currentPosition);
				BoardToken *token = cell->getLinkedBoardToken();

				if (cell->hasBoardToken())
				{
					if (boardGame->cellHasToken<Mine>(cell))
					{
						boardGame->getScreen().getLogger()
							<< "Existe una mina en la posicion ("
							<< token->getPosition().x + 1 << ","
							<< token->getPosition().y + 1 << ","
							<< token->getPosition().z + 1 << ")"
							<< endl;
					}
					else if (boardGame->cellHasToken<Soldier>(cell))
					{
						boardGame->getScreen().getLogger()
							<< "Existe una soldado en la posicion ("
							<< token->getPosition().x + 1 << ","
							<< token->getPosition().y + 1 << ","
							<< token->getPosition().z + 1 << ")"
							<< endl;
					}
					else if (boardGame->cellHasToken<Warship>(cell))
					{
						boardGame->getScreen().getLogger()
							<< "Existe una barco en la posicion ("
							<< token->getPosition().x + 1 << ","
							<< token->getPosition().y + 1 << ","
							<< token->getPosition().z + 1 << ")"
							<< endl;
					}
					else if (boardGame->cellHasToken<Airship>(cell))
					{
						boardGame->getScreen().getLogger()
							<< "Existe una avión en la posicion ("
							<< token->getPosition().x + 1 << ","
							<< token->getPosition().y + 1 << ","
							<< token->getPosition().z + 1 << ")"
							<< endl;
					}
				}
			}
		}
	}
}

// pre:
// pos: return the %20 volume of the field
int FieldDetector::getDamageRange()
{
	BoardSize boardSize = boardGame->getBoard()->getSize();
	int minCubeSide = min(min(boardSize.columnCount, boardSize.rowCount), boardSize.levelCount);
	return (minCubeSide * DAMAGE_RANGE_PERCENT / 100.0);
}

// pos: return the power name
string FieldDetector::getPowerName()
{
	return this->name;
}
