/*
 * field-detector.h
 */

#ifndef SRC_BOARD_GAME_CARD_POWER_FIELD_DETECTOR_FIELD_DETECTOR_H_
#define SRC_BOARD_GAME_CARD_POWER_FIELD_DETECTOR_FIELD_DETECTOR_H_

#include "../../../core/power/power.h"
#include "../../board-game.h"

class BoardGame;
class FieldDetector : public Power
{
private:
	BoardGame *boardGame;

public:
	//Pre: Receives the game board as a parameter
	//Post: Create an instance of Field Detector
	FieldDetector(BoardGame *boardGame);
	//Destructor
	virtual ~FieldDetector();

	static const int DURATION = 1;
	static const int DAMAGE_RANGE_PERCENT = 20;
	static const int RANGE = 10;
	
	//Pre: ---------
	//Post: Activate the power of the card and execute it on the board
	void activatePower();
	
	//Pre:-------------
	//Post: Return the %20 volume of the damage range
	int getDamageRange();
	
	//Pre:-------------
	//Post: Return the power name
	std::string getPowerName();
};

#endif /* SRC_BOARD_GAME_CARD_POWER_FIELD_DETECTOR_FIELD_DETECTOR_H_ */
