/*
 * direct-attack.cpp
 */

#include "direct-attack.h"

using namespace std;

DirectAttack::DirectAttack(BoardGame *boardGame) : Power(DURATION, DAMAGE_RANGE)
{
	this->name = "Ataque Directo";
	this->boardGame = boardGame;

	this->commander = boardGame->getCurrentCommander();
	if (commander == NULL)
	{
		throw "El comandante debe ser no nulo";
	}
}

DirectAttack::~DirectAttack()
{
}

// pre: select a soldier in the board to perform a direct attack, selecting the attack direction.
// pos: Kill the first object ocurrence. If the attack does not smash an object, then finish when touch the end of the board
void DirectAttack::activatePower()
{
	int option;
	string direction;

	SoldierList *soldierList = commander->getMilitaryUnits<Soldier>();

	bool validOption = false;
	while (!validOption)
	{
		boardGame->displayedSubordinates(soldierList);

		boardGame->getScreen().getLogger().writeLine();
		boardGame->getScreen().getLogger() << "Ingresá el soldado deseado de la lista: ";
		option = boardGame->getScreen().readValue<int>();
		validOption = (1 <= option && option <= (int)soldierList->elementCount());
	}
	boardGame->getScreen().getLogger().writeLine();

	Position soldierPosition = soldierList->get(option)->getPosition();

	boardGame->getScreen().getLogger() << "Seleccioná la dirección de disparo (norte, noreste, este, sureste, sur, suroeste, oeste, noroeste): ";
	direction = boardGame->getScreen().readValue<string>();

	int dx = 0, dy = 0;

	bool invalidDirection = true;
	while (invalidDirection)
	{
		if (direction == "norte")
		{
			dy = -1;

			invalidDirection = false;
		}
		else if (direction == "noreste")
		{
			dx = -1;
			dy = -1;

			invalidDirection = false;
		}
		else if (direction == "este")
		{
			dx = 1;

			invalidDirection = false;
		}
		else if (direction == "sureste")
		{
			dx = 1;
			dy = 1;

			invalidDirection = false;
		}
		else if (direction == "sur")
		{
			dy = 1;

			invalidDirection = false;
		}
		else if (direction == "suroeste")
		{
			dx = -1;
			dy = 1;

			invalidDirection = false;
		}
		else if (direction == "oeste")
		{
			dx = -1;

			invalidDirection = false;
		}
		else if (direction == "noroeste")
		{
			dx = 1;
			dy = -1;

			invalidDirection = false;
		}
		else
		{
			boardGame->getScreen().getLogger() << "Dirección inválida. Elegí de nuevo (norte, noreste, este, sureste, sur, suroeste, oeste, noroeste): " << endl;
		}
	}

	bool foundObject = false;

	Position currentPosition;
	currentPosition.x = soldierPosition.x + dx;
	currentPosition.y = soldierPosition.y + dy;
	currentPosition.z = soldierPosition.z;

	// the attack across the board until find an object, stash with the limit of the board or touch the water
	while (this->boardGame->getBoard()->isValidPosition(currentPosition) && this->boardGame->getBoard()->getCell(currentPosition)->getTerrain() != WATER && !foundObject)
	{
		Cell *cell = this->boardGame->getBoard()->getCell(currentPosition);
		Subordinate *subortinate = cell->getLinkedBoardToken();

		// check if cell is full
		// check the type of cell token
		// kills if its a plane, ship or soldier, explode if its a mine
		if (cell->hasBoardToken())
		{
			// set the deactivate timer on the cell
			// this->boardGame->getBoard()->getCell(currentPosition)->setDeactivationTimer(1);

			if (boardGame->cellHasToken<Mine>(cell))
			{
				Mine *mine = dynamic_cast<Mine *>(subortinate);
				unsigned int explosivePower = mine->explode();
				delete mine;

				boardGame->getScreen().getLogger() << "Explotaste una mina" << endl;

				cell->clear();
				cell->setDeactivationTimer(explosivePower + 1);
				foundObject = true;
			}
			else if (boardGame->cellHasToken<Soldier>(cell))
			{
				subortinate->destroy();
				boardGame->getScreen().getLogger() << "Le disparaste a un soldado" << endl;

				cell->clear();
				cell->setDeactivationTimer(Power::getDuration() + 1);
				foundObject = true;
			}
			else if (boardGame->cellHasToken<Warship>(cell))
			{
				subortinate->destroy();
				boardGame->getScreen().getLogger() << "Le diste a un barco" << endl;

				cell->clear();
				cell->setDeactivationTimer(Power::getDuration() + 1);
				foundObject = true;
			}
		}

		// move to the next direction
		currentPosition.x += dx;
		currentPosition.y += dy;
	}

	if (!foundObject)
	{
		boardGame->getScreen().getLogger() << "No se encontró ningún objetivo en la dirección especificada." << endl;
	}
}

// pos: return the power name
string DirectAttack::getPowerName()
{
	return this->name;
}
