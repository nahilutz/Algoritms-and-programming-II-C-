/*
 * direct-attack.h
 */

#ifndef SRC_BOARD_GAME_CARD_POWER_DIRECT_ATTACK_DIRECT_ATTACK_H_
#define SRC_BOARD_GAME_CARD_POWER_DIRECT_ATTACK_DIRECT_ATTACK_H_

#include "../../../core/power/power.h"
#include "../../board-game.h"
#include "../../commander/commander.h"

class BoardGame;
class DirectAttack : public Power
{
private:
	BoardGame *boardGame;
	Commander *commander;

public:
	//Pre: Receives the game board as a parameter
	//Post: Create an instance of Direct Attack
	DirectAttack(BoardGame *boardGame);
	//Pre:
	//Post: Destructor
	virtual ~DirectAttack();

	static const int DURATION = 1;
	static const int DAMAGE_RANGE = -1;
	//Pre: ---------
	//Post: Activate the power of the card and execute it on the board
	void activatePower();
	// return the power name
	std::string getPowerName();
};

#endif /* SRC_BOARD_GAME_CARD_POWER_DIRECT_ATTACK_DIRECT_ATTACK_H_ */
