/*
 * misile-burst.cpp
 */

#include "misile-burst.h"
using namespace std;

MisileBurst::MisileBurst(BoardGame *boardGame) : Power(DURATION, DAMAGE_RANGE)
{
	this->name = "Ráfaga De Misiles";
	this->boardGame = boardGame;

	this->commander = boardGame->getCurrentCommander();
	if (commander == NULL)
	{
		throw "El comandante debe ser no nulo";
	}
}

MisileBurst::~MisileBurst()
{
}

void MisileBurst::activatePower()
{
	int option;
	string subordinateOption;
	Position subordinatePosition;

	boardGame->getScreen().getLogger() << "Seleccioná la opción para lanzar ráfaga de misiles (avion, barco, soldado): ";
	subordinateOption = boardGame->getScreen().readValue<string>();

	bool validOption = false;
	bool validSubordinateSelection = false;
	while (!validSubordinateSelection)
	{
		if (subordinateOption == "avion")
		{
			AirshipList *airshipList = commander->getMilitaryUnits<Airship>();

			if (airshipList->elementCount() > 0)
			{
				while (!validOption)
				{
					boardGame->displayedSubordinates(airshipList);

					boardGame->getScreen().getLogger() << "Ingresá el avion deseado de la lista: ";
					option = boardGame->getScreen().readValue<int>();
					validOption = (1 <= option && option <= (int)airshipList->elementCount());
				}

				subordinatePosition = airshipList->get(option)->getPosition();
				validSubordinateSelection = true;
			}
		}
		else if (subordinateOption == "barco")
		{
			WarshipList *warshipList = commander->getMilitaryUnits<Warship>();

			if (warshipList->elementCount() > 0)
			{
				while (!validOption)
				{
					boardGame->displayedSubordinates(warshipList);

					boardGame->getScreen().getLogger() << "Ingresá el barco deseado de la lista: ";
					option = boardGame->getScreen().readValue<int>();
					validOption = (1 <= option && option <= (int)warshipList->elementCount());
				}

				subordinatePosition = warshipList->get(option)->getPosition();
				validSubordinateSelection = true;
			}
		}
		else if (subordinateOption == "soldado")
		{
			SoldierList *soldierList = commander->getMilitaryUnits<Soldier>();

			if (soldierList->elementCount() > 0)
			{
				while (!validOption)
				{
					boardGame->displayedSubordinates(soldierList);

					boardGame->getScreen().getLogger() << "Ingresá el soldeado deseado de la lista: ";
					option = boardGame->getScreen().readValue<int>();
					validOption = (1 <= option && option <= (int)soldierList->elementCount());
				}

				subordinatePosition = soldierList->get(option)->getPosition();
				validSubordinateSelection = true;
			}
		}
		else
		{
			boardGame->getScreen().getLogger() << "Opción inválida. Elegí de nuevo (avion, barco, soldado): " << endl;
		}
	}

	int dx = 0, dy = 0;

	List<string> *directions = new List<string>();
	directions->append("norte");
	directions->append("noreste");
	directions->append("este");
	directions->append("sureste");
	directions->append("sur");
	directions->append("suroeste");
	directions->append("oeste");
	directions->append("noroeste");

	bool foundObject = false;

	Position currentPosition;

	directions->resetCursor();
	while (directions->advanceCursor())
	{
		string direction = directions->getCursor();
		assignDisplacements(direction, dx, dy);

		currentPosition.x = subordinatePosition.x + dx;
		currentPosition.y = subordinatePosition.y + dy;
		currentPosition.z = subordinatePosition.z;

		while (this->boardGame->getBoard()->isValidPosition(currentPosition) && !foundObject)
		{
			Cell *cell = this->boardGame->getBoard()->getCell(currentPosition);
			BoardToken *token = cell->getLinkedBoardToken();

			// mata si es un avión, barco o soldado, explota si es una mina
			if (cell->hasBoardToken())
			{
				if (boardGame->cellHasToken<Mine>(cell))
				{
					Mine *mine = dynamic_cast<Mine *>(token);
					unsigned int explosivePower = mine->explode();
					delete mine;

					cell->clear();
					cell->setDeactivationTimer(explosivePower + 1);
					boardGame->getScreen().getLogger() << "Explotaste una mina" << endl;
					foundObject = true;
				}
				else if (boardGame->cellHasToken<Soldier>(cell))
				{
					token->destroy();
					boardGame->getScreen().getLogger() << "Le disparaste a un soldado" << endl;

					cell->clear();
					cell->setDeactivationTimer(Power::getDuration() + 1);
					foundObject = true;
				}
				else if (boardGame->cellHasToken<Warship>(cell))
				{
					token->destroy();
					boardGame->getScreen().getLogger() << "Le diste a un barco" << endl;

					cell->clear();
					cell->setDeactivationTimer(Power::getDuration() + 1);
					foundObject = true;
				}
			}

			// pasa a la siguiente dirección
			currentPosition.x += dx;
			currentPosition.y += dy;
		}
	}

	if (!foundObject)
	{
		boardGame->getScreen().getLogger() << "No se encontró ningún objetivo en la dirección especificada." << endl;
	}

	delete directions;
}

void MisileBurst::assignDisplacements(string direction, int &dx, int &dy) const
{
	if (direction == "norte")
	{
		dy = -1;
	}
	else if (direction == "noreste")
	{
		dx = -1;
		dy = -1;
	}
	else if (direction == "este")
	{
		dx = 1;
	}
	else if (direction == "sureste")
	{
		dx = 1;
		dy = 1;
	}
	else if (direction == "sur")
	{
		dy = 1;
	}
	else if (direction == "suroeste")
	{
		dx = -1;
		dy = 1;
	}
	else if (direction == "oeste")
	{
		dx = -1;
	}
	else if (direction == "noroeste")
	{
		dx = 1;
		dy = -1;
	}
}
