/*
 * misile-burst.h
 */

#ifndef SRC_BOARD_GAME_CARD_POWER_MISILE_BURST_MISILE_BURST_H_
#define SRC_BOARD_GAME_CARD_POWER_MISILE_BURST_MISILE_BURST_H_

#include "../../../core/power/power.h"
#include "../../board-game.h"
#include "../../commander/commander.h"

class BoardGame;
class MisileBurst : public Power
{
private:
	BoardGame *boardGame;
	Commander *commander;

public:
	//Pre: Receives the game board as a parameter
	//Post: Create an instance of Misile Burst
	MisileBurst(BoardGame *boardGame);
	
	//Destructor 
	virtual ~MisileBurst();

	static const int DURATION = 4;
	static const int DAMAGE_RANGE = -1;
	
	//Pre: ---------
	//Post: Activate the power of the card and execute it on the board
	void activatePower();

private:
	void assignDisplacements(std::string direction, int &dx, int &dy) const;
};

#endif /* SRC_BOARD_GAME_CARD_POWER_MISILE_BURST_MISILE_BURST_H_ */
