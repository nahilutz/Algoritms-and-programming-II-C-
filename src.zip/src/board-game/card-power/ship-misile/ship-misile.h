/*
 * ship-misile.h
 *
 */

#ifndef SRC_BOARD_GAME_CARD_POWER_SHIP_MISILE_SHIP_MISILE_H_
#define SRC_BOARD_GAME_CARD_POWER_SHIP_MISILE_SHIP_MISILE_H_

#include "../../../core/power/power.h"
#include "../../board-game.h"
#include "../../commander/commander.h"

class BoardGame;
class ShipMisile : public Power
{
private:
	BoardGame *boardGame;
	Commander *commander;

public:
	//Pre: Receives the game board as a parameter
	//Post: Create an instance of chemical attack
	ShipMisile(BoardGame *boardGame);
	
	//Destructor
	virtual ~ShipMisile();

	static const int DURATION = 1;
	static const int DAMAGE_RANGE = -1;
	
	//Pre: ---------
	//Post: Activate the power of the card and execute it on the board
	void activatePower();
};

#endif /* SRC_BOARD_GAME_CARD_POWER_SHIP_MISILE_SHIP_MISILE_H_ */
