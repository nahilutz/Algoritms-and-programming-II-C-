/*
 * ship-misile.cpp
 */

#include "ship-misile.h"
using namespace std;

ShipMisile::ShipMisile(BoardGame *boardGame) : Power(DURATION, DAMAGE_RANGE)
{
	this->name = "Misil De Barco";
	this->boardGame = boardGame;

	this->commander = boardGame->getCurrentCommander();
	if (commander == NULL)
	{
		throw "El comandante debe ser no nulo";
	}
}

ShipMisile::~ShipMisile()
{
}

void ShipMisile::activatePower()
{
	WarshipList *warshipList = commander->getMilitaryUnits<Warship>();

	int option;
	bool validOption = false;
	string direction;
	bool invalidDirection = true;

	while (!validOption)
	{
		boardGame->displayedSubordinates(warshipList);

		boardGame->getScreen().getLogger() << "Ingresá el barco deseado de la lista: ";
		option = boardGame->getScreen().readValue<int>();
		validOption = (1 <= option && option <= (int)warshipList->elementCount());
	}
	boardGame->getScreen().getLogger();

	Position warshipPosition = warshipList->get(option)->getPosition();

	boardGame->getScreen().getLogger() << "Seleccioná la dirección de disparo (norte, noreste, este, sureste, sur, suroeste, oeste, noroeste): ";
	direction = boardGame->getScreen().readValue<string>();

	int dx = 0, dy = 0;

	while (invalidDirection)
	{
		if (direction == "norte")
		{
			dy = -1;

			invalidDirection = false;
		}
		else if (direction == "noreste")
		{
			dx = -1;
			dy = -1;

			invalidDirection = false;
		}
		else if (direction == "este")
		{
			dx = 1;

			invalidDirection = false;
		}
		else if (direction == "sureste")
		{
			dx = 1;
			dy = 1;

			invalidDirection = false;
		}
		else if (direction == "sur")
		{
			dy = 1;

			invalidDirection = false;
		}
		else if (direction == "suroeste")
		{
			dx = -1;
			dy = 1;

			invalidDirection = false;
		}
		else if (direction == "oeste")
		{
			dx = -1;

			invalidDirection = false;
		}
		else if (direction == "noroeste")
		{
			dx = 1;
			dy = -1;

			invalidDirection = false;
		}
		else
		{
			boardGame->getScreen().getLogger() << "Dirección inválida. Elegí de nuevo (norte, noreste, este, sureste, sur, suroeste, oeste, noroeste): " << endl;
		}
	}

	bool foundObject = false;

	Position currentPosition;
	currentPosition.x = warshipPosition.x + dx;
	currentPosition.y = warshipPosition.y + dy;
	currentPosition.z = warshipPosition.z;

	// el ataque a través del tablero hasta encontrar un objeto, o llegar al límite del tablero
	while (this->boardGame->getBoard()->isValidPosition(currentPosition) &&
		   !foundObject &&
		   boardGame->getBoard()->getCell(currentPosition)->getTerrain() == WATER)
	{
		Cell *currentCell = this->boardGame->getBoard()->getCell(currentPosition);
		BoardToken *token = currentCell->getLinkedBoardToken();

		// mata si es barco, explota si es una mina
		if (currentCell->hasBoardToken())
		{
			if (boardGame->cellHasToken<Mine>(currentCell))
			{
				Mine *mine = dynamic_cast<Mine *>(token);
				unsigned int explosivePower = mine->explode();

				boardGame->getScreen().getLogger() << "Explotaste una mina" << endl;

				currentCell->setDeactivationTimer(explosivePower + 1);
				delete mine;
				foundObject = true;
			}
			else if (boardGame->cellHasToken<Warship>(currentCell))
			{
				token->destroy();
				boardGame->getScreen().getLogger() << "Le diste a un barco" << endl;
				currentCell->clear();
				currentCell->setDeactivationTimer(Power::getDuration() + 1);
				foundObject = true;
			}
		}

		// pasar a la siguiente dirección
		currentPosition.x += dx;
		currentPosition.y += dy;
	}

	if (!foundObject)
	{
		boardGame->getScreen().getLogger() << "No se encontró ningún objetivo en la dirección especificada." << endl;
	}
}
