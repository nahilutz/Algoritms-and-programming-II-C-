/*
 * chemical-attack.cpp
 */

#include "chemical-attack.h"

using namespace std;

ChemicalAttack::ChemicalAttack(BoardGame *boardGame) : Power(DURATION, DAMAGE_RANGE_PER_TOKEN)
{
	this->name = "Ataque Quimico";
	this->boardGame = boardGame;
}

ChemicalAttack::~ChemicalAttack()
{
}

// pre: select a position in the getBoard() to activate the power. The position must be exists in the getBoard() range
// pos: create radius around the selected field with disabled tokens
void ChemicalAttack::activatePower()
{
	BoardSize boardSize = boardGame->getBoard()->getSize();
	Position pos;
	bool invalidPosition = true;

	boardGame->getScreen().getLogger() << this->name << ": Ingresá una posicion en el tablero para contaminar la zona" << endl;

	// while the selected field is not a valid fiel position in the getBoard(), the player must re select the position
	while (invalidPosition)
	{
		boardGame->getScreen().getLogger() << "Fila: ";
		pos.y = boardGame->getScreen().readValue<int>() - 1;

		boardGame->getScreen().getLogger() << "Columna: ";
		pos.x = boardGame->getScreen().readValue<int>() - 1;

		boardGame->getScreen().getLogger() << "Nivel: ";
		pos.z = boardGame->getScreen().readValue<int>() - 1;

		if (this->boardGame->getBoard()->isValidPosition(pos))
		{
			invalidPosition = false;
		}
		else
		{
			boardGame->getScreen().getLogger() << "Ingresá una posicion dentro de las dimensiones del tablero." << endl;
			boardGame->getScreen().getLogger().writeLine();
		}
	}
	boardGame->getScreen().getLogger().writeLine();

	// x: columna
	// y: fila
	// z: nivel

	// contaminate the tokens in the volume
	// [x0-range, x0+range] x [y0-range, y0+range] x [z0-range, z0+range]
	for (int range = 1; range <= Power::getDamageRange(); range++)
	{
		int minX = max(0, pos.x - range);
		int maxX = min(boardSize.columnCount - 1, pos.x + range);

		int minY = max(0, pos.y - range);
		int maxY = min(boardSize.rowCount - 1, pos.y + range);

		int minZ = max(0, pos.z - range);
		int maxZ = min(boardSize.levelCount - 1, pos.z + range);

		for (int i = minX; i <= maxX; i++)
		{
			for (int j = minY; j <= maxY; j++)
			{
				for (int k = minZ; k <= maxZ; k++)
				{
					Position currentPosition;
					currentPosition.x = i;
					currentPosition.y = j;
					currentPosition.z = k;

					Cell *currentCell = this->boardGame->getBoard()->getCell(currentPosition);
					BoardToken *token = currentCell->getLinkedBoardToken();
					Mine *mine = NULL;

					// check if cell is full
					// check the type of cell token
					// kills if its a plane, ship or soldier, explode if its a mine
					if (currentCell->hasBoardToken())
					{
						if (boardGame->cellHasToken<Mine>(currentPosition))
						{
							mine = dynamic_cast<Mine *>(token);
							mine->explode();
							boardGame->getScreen().getLogger() << "Explotaste una mina." << endl;
						}
						else if (boardGame->cellHasToken<Soldier>(currentPosition))
						{
							boardGame->getScreen().getLogger() << "Contaminaste a un soldado." << endl;
						}
						else if (boardGame->cellHasToken<Airship>(currentPosition))
						{
							boardGame->getScreen().getLogger() << "Contaminaste un avion." << endl;
						}
						else if (boardGame->cellHasToken<Warship>(currentPosition))
						{
							boardGame->getScreen().getLogger() << "Contaminaste un barco" << endl;
						}

						token->destroy();
						currentCell->clear();
						// set the deactivate timer on the cell
						currentCell->setDeactivationTimer(Power::getDuration() - range + 2);

						// Si había una mina libera memoria
						if (mine != NULL)
						{
							delete mine;
						}
					}
				}
			}
		}
	}
}

// pos: return the power name
string ChemicalAttack::getPowerName()
{
	return this->name;
}
