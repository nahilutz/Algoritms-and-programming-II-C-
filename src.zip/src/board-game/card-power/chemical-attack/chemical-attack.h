/*
 * chemical-attack.h

 */

#ifndef SRC_BOARD_GAME_CARD_POWER_CHEMICAL_ATTACK_H_
#define SRC_BOARD_GAME_CARD_POWER_CHEMICAL_ATTACK_H_

#include "../../../core/power/power.h"
#include "../../board-game.h"

class BoardGame;
class ChemicalAttack : public Power
{
private:
	BoardGame *boardGame;

public:
	//Pre: Receives the game board as a parameter
	//Post: Create an instance of chemical attack
	ChemicalAttack(BoardGame *boardGame);
	
	//Destructor
	~ChemicalAttack();

	static const int DURATION = 10;
	static const int DAMAGE_RANGE_PER_TOKEN = 5;
	
	//Pre: ---------
	//Post: Activate the power of the card and execute it on the board
	void activatePower();
	
	//Pre: ---------
	//Post: Return the power name
	std::string getPowerName();
};

#endif /* SRC_BOARD_GAME_CARD_POWER_CHEMICAL_ATTACK_H_ */
