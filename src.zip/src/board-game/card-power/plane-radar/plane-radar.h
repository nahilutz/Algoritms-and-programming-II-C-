/*
 * plane-radar.h
 */

#ifndef SRC_BOARD_GAME_CARD_POWER_PLANE_RADAR_PLANE_RADAR_H_
#define SRC_BOARD_GAME_CARD_POWER_PLANE_RADAR_PLANE_RADAR_H_

#include "../../../core/power/power.h"
#include "../../board-game.h"
#include "../../commander/commander.h"

class BoardGame;
class PlaneRadar : public Power
{
private:
	BoardGame *boardGame;
	Commander *commander;

public:
	//Pre: Receives the game board as a parameter
	//Post: Create an instance of Plane Radar
	PlaneRadar(BoardGame *boardGame);
	
	// Destructor
	virtual ~PlaneRadar();

	static const int DURATION = 0;
	static const int DAMAGE_RANGE = 3;
	
	//Pre: ---------
	//Post: Activate the power of the card and execute it on the board
	void activatePower();
};

#endif /* SRC_BOARD_GAME_CARD_POWER_PLANE_RADAR_PLANE_RADAR_H_ */
