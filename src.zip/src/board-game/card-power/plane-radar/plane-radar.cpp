/*
 * plane-radar.cpp
 */

#include "plane-radar.h"

using namespace std;

PlaneRadar::PlaneRadar(BoardGame *boardGame) : Power(DURATION, DAMAGE_RANGE)
{
	this->name = "Avión Radar";
	this->boardGame = boardGame;

	this->commander = boardGame->getCurrentCommander();
	if (commander == NULL)
	{
		throw "El comandante debe ser no nulo";
	}
}

PlaneRadar::~PlaneRadar()
{
}

void PlaneRadar::activatePower()
{
	AirshipList *airshipList = commander->getMilitaryUnits<Airship>();

	int option;
	bool validOption = false;
	while (!validOption)
	{
		boardGame->displayedSubordinates(airshipList);

		boardGame->getScreen().getLogger() << "Ingresá el avion deseado de la lista: ";
		option = boardGame->getScreen().readValue<int>();
		validOption = (1 <= option && option <= (int)airshipList->elementCount());
	}

	Position planePosition = airshipList->get(option)->getPosition();

	// Obtiene las dimensiones del tablero
	int rowCount = boardGame->getGameConfig()->getBoardRowCount();
	int columnCount = boardGame->getGameConfig()->getBoardColumnCount();

	// x: columna
	// y: fila
	// z: nivel

	// Busca minas debajo de la columna de un avión
	// La columna será [x0-range, x0+range] x [y0-range, y0+range] x [0, z0]
	int range = getDamageRange();

	int minX = max(planePosition.x - range, 0);
	int maxX = min(planePosition.x + range, columnCount - 1);

	int minY = max(planePosition.y - range, 0);
	int maxY = min(planePosition.y + range, rowCount - 1);

	int minZ = 0;
	int maxZ = planePosition.z;

	Position checkedPosition;
	for (int i = minX; i <= maxX; i++)
	{
		for (int j = minY; j <= maxY; j++)
		{
			for (int k = minZ; k <= maxZ; k++)
			{
				checkedPosition.x = i;
				checkedPosition.y = j;
				checkedPosition.z = k;

				// Se fija si la celda tiene una mina
				if (boardGame->cellHasToken<Mine>(checkedPosition))
				{
					boardGame->getScreen().getLogger()
						<< "Mina detectada por el avión radar en posicion: ("
						<< checkedPosition.x + 1 << ","
						<< checkedPosition.y + 1 << ","
						<< checkedPosition.z + 1 << ")"
						<< endl;
				}
			}
		}
	}
}
