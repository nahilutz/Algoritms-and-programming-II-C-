/*
 * board-game.cpp
 */

#include "board-game.h"

using namespace std;

GameConfig *BoardGame::startGameConfigDialog()
{
	screen().printTitle();
	return screen().startGameConfigDialog();
}

BoardGame::BoardGame(GameConfig *gameConfig)
{
	if (gameConfig == NULL)
	{
		throw "La configuración del juego debe ser no nula";
	}

	this->gameConfig = gameConfig;
	this->initialize();

	// Inicializo los nombres de los soldados y armamentos
	tokenNameMap[typeid(BoardToken).name()] = "Ficha";
	tokenNameMap[typeid(BoardToken *).name()] = "Ficha";
	tokenNameMap[typeid(Soldier).name()] = "Soldado";
	tokenNameMap[typeid(Soldier *).name()] = "Soldado";
	tokenNameMap[typeid(Airship).name()] = "Avión";
	tokenNameMap[typeid(Airship *).name()] = "Avión";
	tokenNameMap[typeid(Warship).name()] = "Buque";
	tokenNameMap[typeid(Warship *).name()] = "Buque";

	this->deck = new Deck();
}

BoardGame::~BoardGame()
{
	// Libero minas sueltas por el tablero.
	CellCube *cellCube = board->getCellCube();

	cellCube->resetCursor();
	while (cellCube->advanceCursor())
	{
		CellLevel *level = cellCube->getCursor();
		level->resetCursor();
		while (level->advanceCursor())
		{
			CellRow *row = level->getCursor();
			row->resetCursor();
			while (row->advanceCursor())
			{
				Cell *cell = row->getCursor();
				if (cellHasToken<Mine>(cell))
				{
					Mine *mine = dynamic_cast<Mine *>(cell->getLinkedBoardToken());
					delete mine;
				}
			}
		}
	}

	commanders->resetCursor();
	while (commanders->advanceCursor())
	{
		delete commanders->getCursor();
	}
	delete commanders;

	delete deck;
	delete board;
	delete gameConfig;
}

GameConfig *BoardGame::getGameConfig() const
{
	return this->gameConfig;
}

Board *BoardGame::getBoard() const
{
	return this->board;
}

void BoardGame::initialize()
{
	// Creación del tablero
	BoardSize size = {gameConfig->getBoardRowCount(), gameConfig->getBoardColumnCount(), gameConfig->getBoardLevelCount()};
	this->board = new Board(size);

	// Inicialización del terreno de las celdas (solo tierra y aire).
	CellCube *cellCube = board->getCellCube();

	cellCube->resetCursor();
	while (cellCube->advanceCursor())
	{
		CellLevel *cellLevel = cellCube->getCursor();

		cellLevel->resetCursor();
		while (cellLevel->advanceCursor())
		{
			CellRow *cellRow = cellLevel->getCursor();

			cellRow->resetCursor();
			while (cellRow->advanceCursor())
			{
				Cell *cell = cellRow->getCursor();
				CellTerrain terrain = defineCellTerrain(*cell);
				cell->setTerrain(terrain);
			}
		}
	}

	// Creación de masas de agua en el tablero.
	for (int i = 0; i < RIVER_COUNT; i++)
	{
		generateRiver();
	}
	for (int i = 0; i < LAKE_COUNT; i++)
	{
		generateLake();
	}

	// Creación del los comandantes, sus soldados y armamentos
	this->commanders = new CommanderList();
	PositionList *notAvailablePositions = new PositionList();

	for (int i = 0; i < gameConfig->getCommanderCount(); i++)
	{
		Commander *commander = new Commander(i + 1);

		generateCommanderSoldiers(commander, notAvailablePositions);
		generateCommanderAirships(commander, notAvailablePositions);
		generateCommanderWarships(commander, notAvailablePositions);

		// Ubico las fichas sobre las celdas
		SubordinateList *subordinates = commander->getActiveSubordinates();

		subordinates->resetCursor();
		while (subordinates->advanceCursor())
		{
			Subordinate *subordinate = subordinates->getCursor();
			board->getCell(subordinate->getPosition())->linkBoardToken(subordinate);
		}

		this->commanders->append(commander);
		delete subordinates;
	}

	delete notAvailablePositions;
}

void BoardGame::generateCommanderSoldiers(Commander *commander, PositionList *notAvailablePositions)
{
	if (commander == NULL)
	{
		throw "El commandante debe ser no nulo";
	}
	if (notAvailablePositions == NULL)
	{
		throw "La lista de posiciones no disponibles debe ser no nula";
	}

	Region soldierRegion = {board->getSize().rowCount, board->getSize().columnCount, HORIZONT_HEIGHT};

	for (int i = 0; i < gameConfig->getCommanderSoldiersCount(); i++)
	{
		Position soldierPosition;

		// Verifico que en esta posición el terreno sea tierra
		bool validSoldierTerrain = false;
		while (!validSoldierTerrain)
		{
			soldierPosition = generateRandomUniquePosition(notAvailablePositions, soldierRegion);
			validSoldierTerrain = board->getCell(soldierPosition)->getTerrain() == GROUND;
		}

		Soldier *soldier = new Soldier(soldierPosition, commander);
		soldier->setAllowedTerrain(GROUND);

		commander->addSubordinate(soldier);
		notAvailablePositions->append(soldierPosition);
	}
}

void BoardGame::generateCommanderAirships(Commander *commander, PositionList *notAvailablePositions)
{
	if (commander == NULL)
	{
		throw "El commandante debe ser no nulo";
	}
	if (notAvailablePositions == NULL)
	{
		throw "La lista de posiciones no disponibles debe ser no nula";
	}

	Region airshipRegion = {board->getSize().rowCount, board->getSize().columnCount, board->getSize().levelCount - HORIZONT_HEIGHT};

	for (int i = 0; i < gameConfig->getCommanderAircraftCount(); i++)
	{
		Position airshipPosition;

		// Verifico que en esta posición el terreno sea tierra
		bool validAirshipTerrain = false;
		while (!validAirshipTerrain)
		{
			Position offset = {0, 0, HORIZONT_HEIGHT};
			airshipPosition = generateRandomUniquePosition(notAvailablePositions, airshipRegion, offset);
			validAirshipTerrain = board->getCell(airshipPosition)->getTerrain() == AIR;
		}

		Airship *airship = new Airship(airshipPosition, commander);
		airship->setAllowedTerrain(AIR);

		commander->addSubordinate(airship);
		notAvailablePositions->append(airshipPosition);
	}
}

void BoardGame::generateCommanderWarships(Commander *commander, PositionList *notAvailablePositions)
{
	if (commander == NULL)
	{
		throw "El commandante debe ser no nulo";
	}
	if (notAvailablePositions == NULL)
	{
		throw "La lista de posiciones no disponibles debe ser no nula";
	}

	Region warshipsRegion = {board->getSize().rowCount, board->getSize().columnCount, HORIZONT_HEIGHT};

	for (int i = 0; i < gameConfig->getCommanderWarshipsCount(); i++)
	{
		Position warshipPosition;

		// Verifico que en esta posición el terreno sea tierra
		bool validWarshipTerrain = false;
		while (!validWarshipTerrain)
		{
			warshipPosition = generateRandomUniquePosition(notAvailablePositions, warshipsRegion);
			validWarshipTerrain = board->getCell(warshipPosition)->getTerrain() == WATER;
		}

		Warship *warship = new Warship(warshipPosition, commander);
		warship->setAllowedTerrain(WATER);

		commander->addSubordinate(warship);
		notAvailablePositions->append(warshipPosition);
	}
}

CellTerrain BoardGame::defineCellTerrain(const Cell &cell) const
{
	if (0 <= cell.getPosition().z && cell.getPosition().z < HORIZONT_HEIGHT)
	{
		return GROUND;
	}
	else
	{
		return AIR;
	}
}

Position BoardGame::generateRandomUniquePosition(PositionList *notAvailablePositions, BoardSize size) const
{
	Position offset = {0, 0, 0};
	return generateRandomUniquePosition(notAvailablePositions, size, offset);
}

Position BoardGame::generateRandomUniquePosition(PositionList *notAvailablePositions, BoardSize size, Position offset) const
{
	if (notAvailablePositions == NULL)
	{
		throw "La lista de posiciones no disponibles debe ser no nula";
	}

	bool uniquePosition = false;
	Position pos;

	while (!uniquePosition)
	{
		pos = core::generateRandomPosition(size.rowCount, size.columnCount, size.levelCount);
		pos = pos + offset;
		uniquePosition = core::isUniquePosition(pos, notAvailablePositions);
	}

	return pos;
}

void BoardGame::start()
{
	screen().printInstructions(gameConfig);

	GameStatus status = checkGameStatus();

	for (int k = 0; !status.hasWinner; k++)
	{
		int commanderNumber = k % gameConfig->getCommanderCount() + 1;
		Commander *commander = getCommanderByNumber(commanderNumber);
		setCurrentCommander(commander);

		screen().printBoard(board, commander);

		screen().printTurnStart(k + 1, commander);

		startDropMineDialog(commander);

		status = checkGameStatus();

		if (!status.hasWinner)
		{
			screen().printBoard(board, commander);
			startMoveSoldierDialog(commander);
			startCardActionDialog(commander);
			status = checkGameStatus();
		}

		updateCellsTimer();
	}

	screen().printGameEnd(status.winner);
}

void BoardGame::setCurrentCommander(Commander *commander)
{
	this->currentCommander = commander;
}

Commander *BoardGame::getCurrentCommander() const
{
	return this->currentCommander;
}

void BoardGame::displayCards(CardList *cards)
{
	if (cards == NULL)
	{
		throw "La lista de cartas debe ser no nula";
	}

	int number = 1;
	cards->resetCursor();
	while (cards->advanceCursor())
	{
		Card *card = cards->getCursor();
		string name = card->getName();
		if (card->isEnabled())
		{
			screen().getLogger() << number << ". " << name << endl;
			number++;
		}
	}
}

void BoardGame::startCardActionDialog(Commander *commander)
{
	if (commander == NULL)
	{
		throw "El comandante debe ser no nulo";
	}

	// checkear que no se pase de la cantidad de las cartas
	string confirmStr;
	bool confirm = false;
	CardList *cardsInHand;
	int cardNumber;

	// agarrar carta
	Card *newCard = this->deck->generateCard(this);
	commander->addCard(newCard);

	// decir que carta agarro
	screen().getLogger().writeLine();
	screen().getLogger() << "Agarro la carta >> " << newCard->getName() << endl;

	// mostrar mano
	cardsInHand = commander->getEnabledCards();
	screen().getLogger().writeLine();
	screen().getLogger().writeLine("Tiene estas cartas en la mano: ");
	displayCards(cardsInHand);

	// preguntar si quiere jugar alguna carta

	screen().getLogger().writeLine();
	screen().getLogger() << ">> " << commander->getName() << " Desea activar alguna carta? [y/n] ";
	confirmStr = screen().readValue<string>();
	confirm = confirmStr == "y";

	if (!confirm)
	{
		screen().getLogger().writeLine();
		return;
	}

	confirm = false;
	while (!confirm || commander->getEnabledCardsCount() > 0)
	{
		screen().getLogger().writeLine();
		screen().getLogger().write("Elija una carta: ");
		cardNumber = screen().readValue<int>();

		if (cardNumber > commander->getEnabledCardsCount() || cardNumber <=0)
		{
			screen().getLogger().writeLine("La carta elegida es invalida");
			confirm = false;
		}
		else
		{
			// jugar la carta 
			commander->activateCard(cardNumber);
			if (commander->getEnabledCardsCount() < 1)
			{
				return;
			}
			screen().getLogger().writeLine();
			screen().getLogger().write("Le quedan estas cartas en la mano: ");
			screen().getLogger().writeLine();
			displayCards(cardsInHand);

			screen().getLogger().write("Desea jugar otra carta? [y/n] ");
			confirmStr = screen().readValue<string>();
			confirm = confirmStr == "n"; // si pone que si quiero que siga el loop
		}
	}
}

void BoardGame::startDropMineDialog(Commander *commander)
{
	if (commander == NULL)
	{
		throw "El comandante debe ser no nulo";
	}

	// El usuario ingresa coordenadas en base 1.
	// Internamente se manejan coordenadas en base 0.

	Position position;
	bool validPosition = false;
	bool confirm = false;

	while (!confirm)
	{
		while (!validPosition)
		{
			screen().getLogger().writeLine("Dónde quiere dejar la mina?");
			screen().getLogger().write("Fila: ");
			position.y = screen().readValue<int>() - 1;

			screen().getLogger().write("Columna: ");
			position.x = screen().readValue<int>() - 1;

			screen().getLogger().write("Nivel: ");
			position.z = screen().readValue<int>() - 1;

			string error;
			validPosition = validateMineDropPosition(position, commander, error);

			if (!validPosition)
			{
				screen().getLogger().writeLine(error);
				screen().getLogger().writeLine();
			}
		}

		// -------------------------------
		// Confirmación de tiro de mina
		// -------------------------------
		toggleCellMark(position);
		screen().printBoard(board, commander);

		screen().getLogger().writeLine();
		screen().getLogger().write("Desea poner la mina en esta posición? [y/n] ");
		string confirmStr = screen().readValue<string>();
		confirm = confirmStr == "y";

		toggleCellMark(position);

		if (confirm)
		{
			dropMineAt(position, commander);
		}
		else
		{
			validPosition = false;
			screen().getLogger().writeLine();
		}
	}
}

void BoardGame::startMoveSoldierDialog(Commander *commander)
{
	if (commander == NULL)
	{
		throw "El comandante debe ser no nulo";
	}

	// El usuario ingresa coordenadas en base 1.
	// Internamente se manejan coordenadas en base 0.

	string confirmStr;
	bool confirm = false;

	screen().getLogger().writeLine();
	screen().getLogger() << ">> " << commander->getName() << " desea mover un soldado o armamento? [y/n] ";
	confirmStr = screen().readValue<string>();
	confirm = confirmStr == "y";

	if (!confirm)
	{
		screen().getLogger().writeLine();
		return;
	}

	SubordinateList *subordinates = commander->getActiveSubordinates();

	confirm = false;
	int unitNumber = 0;
	while (!confirm)
	{
		screen().getLogger().writeLine();
		screen().getLogger().writeLine("Elija un soldado o armamento:");

		displayedSubordinates(subordinates);

		screen().getLogger().writeLine();
		screen().getLogger().write("Unidad: ");
		unitNumber = screen().readValue<int>();

		if (unitNumber > (int)subordinates->elementCount() || unitNumber <= 0 )
		{
			screen().getLogger().writeLine("La unidad elegida no está disponible");
			confirm = false;
		}
		else
		{
			screen().getLogger().write("Desea mover esta unidad? [y/n] ");
			confirmStr = screen().readValue<string>();
			confirm = confirmStr == "y";
		}
	}

	Subordinate *subordinate = subordinates->get(unitNumber);
	RelativePositionList *positions = getAvailablePositionsForMovingAt(subordinate->getPosition(), commander);

	// Elijo direccion a mover la unidad
	confirm = false;
	int option = 0;
	while (!confirm)
	{
		screen().getLogger() << "Posiciones relativas a la unidad elegida:" << endl;
		displayedRelativePositions(positions);

		screen().getLogger().writeLine();
		screen().getLogger().write("Opción: ");
		option = screen().readValue<int>();

		if (option > (int)positions->elementCount() || option <= 0 )
		{
			screen().getLogger().writeLine("La opción elegida no está disponible");
			confirm = false;
		}
		else
		{
			screen().getLogger().write("Desea mover en esta dirección? [y/n] ");
			confirmStr = screen().readValue<string>();
			confirm = confirmStr == "y";
		}
	}

	RelativePosition position = positions->get(option);
	moveMilitaryUnit(position);

	delete positions;
}

string BoardGame::getTokenDisplayName(BoardToken *token) const
{
	if (dynamic_cast<Soldier *>(token))
	{
		return tokenNameMap.at(typeid(Soldier *).name());
	}
	if (dynamic_cast<Airship *>(token))
	{
		return tokenNameMap.at(typeid(Airship *).name());
	}
	if (dynamic_cast<Warship *>(token))
	{
		return tokenNameMap.at(typeid(Warship *).name());
	}

	return "UNKNOWN";
}

void BoardGame::displayedRelativePositions(RelativePositionList *positions) const
{
	if (positions == NULL)
	{
		throw "La lista de posiciones debe ser no nula";
	}

	int option = 1;
	positions->resetCursor();
	while (positions->advanceCursor())
	{
		RelativePosition position = positions->getCursor();

		screen().getLogger() << option << ". "
							 << " (" << position.relative.x << "," << position.relative.y << "," << position.relative.z << ")"
							 << endl;
		option++;
	}
}

void BoardGame::toggleCellMark(Position position)
{
	if (!board->isValidPosition(position))
	{
		throw "La casilla no existe.";
	}

	Cell *cell = board->getCell(position);

	if (!cell->isMarked())
	{
		cell->mark();
	}
	else
	{
		cell->unmark();
	}
}

Commander *BoardGame::getCommanderByNumber(int number)
{
	validateCommanderNumber(number);

	commanders->resetCursor();
	while (commanders->advanceCursor())
	{
		Commander *commander = commanders->getCursor();

		if (commander->getNumber() == number)
		{
			return commander;
		}
	}
	return NULL;
}

void BoardGame::validateCommanderNumber(int number)
{
	if (number <= 0)
	{
		throw "El número del comandante debe ser mayor a cero.";
	}
}

bool BoardGame::validateMineDropPosition(Position position, Commander *commander, string &error) const
{
	// validación de la posición
	if (!board->isValidPosition(position))
	{
		error = "Ups! La casilla no existe. Elija nuevamente.";
		return false;
	}

	// validación del estado
	if (board->getCell(position)->isDeactivated())
	{
		error = "Ups! La casilla está desactivada. Elija nuevamente.";
		return false;
	}

	// validación de solapamiento con fichas propias
	if (cellHasOwnToken<BoardToken>(position, commander))
	{
		error = "Ups! La casilla contiene una ficha propia. Elija nuevamente.";
		return false;
	}

	error = "No hay error. La posición es válida";
	return true;
}

void BoardGame::updateCellsTimer()
{
	CellCube *cellCube = board->getCellCube();

	cellCube->resetCursor();
	while (cellCube->advanceCursor())
	{
		CellLevel *cellLevel = cellCube->getCursor();

		cellLevel->resetCursor();
		while (cellLevel->advanceCursor())
		{
			CellRow *cellRow = cellLevel->getCursor();

			cellRow->resetCursor();
			while (cellRow->advanceCursor())
			{
				cellRow->getCursor()->updateDeactivationTimer();
			}
		}
	}
}

GameStatus BoardGame::checkGameStatus()
{
	GameStatus status;

	int activeCommandersCount = 0;
	Commander *lastActiveCommaderFound = NULL;

	commanders->resetCursor();
	while (commanders->advanceCursor())
	{
		Commander *commander = commanders->getCursor();

		if (commander->isActive())
		{
			activeCommandersCount++;
			lastActiveCommaderFound = commander;
		}
	}

	status.hasWinner = activeCommandersCount == 1;
	status.winner = status.hasWinner ? lastActiveCommaderFound : NULL;

	return status;
}

RelativePositionList *BoardGame::getAvailablePositionsForMovingAt(Position position, Commander *owner)
{
	if (owner == NULL)
	{
		throw "El comandante debe ser no nulo";
	}

	BoardToken *token = board->getCell(position)->getLinkedBoardToken();

	if (token == NULL)
	{
		throw "No hay un ficha en la posición elegida";
	}

	RelativePositionList *positions = new RelativePositionList();

	CellList *neighbors = board->getCell(position)->getAllNeighbors();

	neighbors->resetCursor();
	while (neighbors->advanceCursor())
	{
		Cell *cell = neighbors->getCursor();
		// cout << "celda: " << cell << endl;

		if (!cell->isDeactivated() && !cellHasOwnToken<BoardToken>(cell->getPosition(), owner) && cell->getTerrain() == token->getAllowedTerrain())
		{
			RelativePosition relativePosition = {position, cell->getPosition() - position};
			positions->append(relativePosition);
		}
	}

	delete neighbors;
	return positions;
}

void BoardGame::moveMilitaryUnit(RelativePosition position)
{
	Position newPosition = position.origin + position.relative;
	Cell *ci = board->getCell(position.origin);
	Cell *cf = board->getCell(newPosition);

	BoardToken *t1 = ci->getLinkedBoardToken();

	// verifico colisión entre unidades
	if (cellHasMilitaryUnit(newPosition))
	{
		BoardToken *t2 = cf->getLinkedBoardToken();

		// Ambas unidades mueren si hay colisión
		if (t1->getOwner()->getNumber() != t2->getOwner()->getNumber())
		{
			// Se destruyen ambas las unidades
			t1->destroy();
			t2->destroy();

			// De desvinculan las fichas de ambas celdas
			ci->clear();
			cf->clear();
		}
	}
	// No hay colisión
	else
	{
		ci->clear();

		if (!this->explodeMineAt(newPosition, t1))
		{
			t1->move(newPosition);
			cf->linkBoardToken(t1);
		}
	}
}

bool BoardGame::cellHasMilitaryUnit(Position position) const
{
	if (!board->isValidPosition(position))
	{
		throw "La casilla no existe en la posición dada";
	}

	BoardToken *token = board->getCell(position)->getLinkedBoardToken();

	Soldier *soldier = dynamic_cast<Soldier *>(token);
	Airship *airship = dynamic_cast<Airship *>(token);
	Warship *warship = dynamic_cast<Warship *>(token);

	return soldier || airship || warship;
}

bool BoardGame::explodeMineAt(Position position, BoardToken *landingToken)
{
	Cell *cell = board->getCell(position);

	if (cellHasToken<Mine>(position))
	{
		Mine *mine = dynamic_cast<Mine *>(cell->getLinkedBoardToken());

		cell->clear();
		cell->setDeactivationTimer(mine->getExplosivePower() + 1);

		landingToken->destroy();
		delete mine;
		return true;
	}
	else
	{
		return false;
	}
}

void BoardGame::dropMineAt(Position position, Commander *owner)
{
	if (!board->isValidPosition(position))
	{
		throw "La casilla no existe en la posición dada";
	}

	Cell *cell = board->getCell(position);

	// Verifico si hay algo que matar
	if (cellHasMilitaryUnit(position))
	{
		BoardToken *token = cell->getLinkedBoardToken();
		token->destroy();
		cell->clear();
		cell->setDeactivationTimer(Mine::DEFAULT_EXPLOSIVE_POWER + 1);
	}
	// Replazo un mina si la hubiere por una propia
	else if (cellHasToken<Mine>(position))
	{
		Mine *mine = dynamic_cast<Mine *>(cell->getLinkedBoardToken());
		delete mine;
		cell->linkBoardToken(new Mine(position, owner));
	}
	else if (cell->isEmpty())
	{
		cell->linkBoardToken(new Mine(position, owner));
	}
}

void BoardGame::generateRiver()
{
	/*
	 * Primeros 5 niveles son de tierra/agua y el resto de aire
	 * en esos 5 niveles dividir en agua o tierra de manera que quede bien
	 * no importa el valor del tamanio que le de el usuario
	 */
	BoardSize size = board->getSize();

	int riverDepth = RIVER_DEPTH;

	int minimumBoardLength = min((int)(size.rowCount * BOARD_DIMENSION_PERCENT / 100.0), MAX_RIVER_LENGTH) + MIN_RIVER_LENGTH;
	int minimumBoardWidth = min((int)(size.columnCount * BOARD_DIMENSION_PERCENT / 100.0), MAX_RIVER_WIDTH) + MIN_RIVER_WIDTH;

	int riverLength = core::generateRandomInt(MIN_RIVER_LENGTH, minimumBoardLength);
	int riverWidth = core::generateRandomInt(MIN_RIVER_WIDTH, minimumBoardWidth);

	generateWaterBody(riverLength, riverWidth, riverDepth);
}

void BoardGame::generateLake()
{
	BoardSize size = board->getSize();

	int minimumBoardRadius = min((int)(size.columnCount * BOARD_DIMENSION_PERCENT / 100.0), MAX_LAKE_RADIUS) + MIN_LAKE_RADIUS;
	int lakeRadius = core::generateRandomInt(MIN_LAKE_RADIUS, minimumBoardRadius);
	int lakeDepth = core::generateRandomInt(MIN_LAKE_DEPTH, MAX_LAKE_DEPTH);

	generateWaterBody(lakeRadius, lakeRadius, lakeDepth);
}

void BoardGame::generateWaterBody(int waterBodyLength, int waterBodyWidth, int waterBodyDepth)
{
	BoardSize size = board->getSize();
	Position position;

	position.z = HORIZONT_HEIGHT;
	while (position.z >= HORIZONT_HEIGHT)
	{
		position = core::generateRandomPosition(size.rowCount, size.columnCount, size.levelCount);
	}

	for (int k = position.z; k <= position.z + waterBodyDepth; k++)
	{
		for (int i = position.x; i <= position.x + waterBodyLength; i++)
		{
			for (int j = position.y; j <= position.y + waterBodyWidth; j++)
			{
				bool validRegion = k < HORIZONT_HEIGHT && i < size.rowCount && j < size.columnCount;
				if (validRegion)
				{
					Position position = {i, j, k};
					board->getCell(position)->setTerrain(WATER);
				}
			}
		}
	}
}
