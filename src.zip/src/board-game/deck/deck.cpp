/*
 * deck.cpp
 */

#include "deck.h"

// pre:
// pos:
Deck::Deck()
{
}

// pre:
// pos: release memory from gameConfig and boardGames pointers
Deck::~Deck()
{
}

// pre: Generate a random number between 1 and 6 and create a power instance according to the random number.
//      Then create a new card with the random power
// pos: Returns a new effect card
Card *Deck::generateCard(BoardGame *boardGame)
{
	int powerId = core::generateRandomInt(1, 6);

	Power *power = NULL;

	switch (powerId)
	{
	case 1:
		power = new ChemicalAttack(boardGame);
		break;
	case 2:
		power = new PlaneRadar(boardGame);
		break;
	case 3:
		power = new ShipMisile(boardGame);
		break;
	case 4:
		power = new DirectAttack(boardGame);
		break;
	case 5:
		power = new MisileBurst(boardGame);
		break;
	case 6:
		power = new FieldDetector(boardGame);
		break;
	}

	Card *card = new Card(power);
	return card;
}
