/*
 * deck.h
 */
#ifndef CORE_DECK_DECK_H_
#define CORE_DECK_DECK_H_

#include "../../core/card/card.h"
#include "../../board-game/board-game.h"

#include "../card-power/chemical-attack/chemical-attack.h"
#include "../card-power/direct-attack/direct-attack.h"
#include "../card-power/field-detector/field-detector.h"
#include "../card-power/misile-burst/misile-burst.h"
#include "../card-power/plane-radar/plane-radar.h"
#include "../card-power/ship-misile/ship-misile.h"

class BoardGame;
class Deck
{
private:
public:
	//Pre: -----------
	//Post: Creates an instance of the shared deck to be used in the game.
	Deck();
	
	//Destructor
	~Deck();
	
	//Pre: Receives the game board as a parameter
	//Post: Generate a card and it is available in the deck
	Card *generateCard(BoardGame *boardGame);
};

#endif /* CORE_DECK_DECK_H_ */
