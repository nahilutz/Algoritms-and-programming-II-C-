/*
 * game-config.h
 *
 */

#ifndef BOARD_GAME_GAME_CONFIG_GAME_CONFIG_H_
#define BOARD_GAME_GAME_CONFIG_GAME_CONFIG_H_

class GameConfig
{
private:
	int commanderCount;
	int boardLevelCount;
	int boardRowCount;
	int boardColumnCount;

public:
	static const int PARAMETER_COUNT = 4;

	// Limite para la cantidad de jugadores
	static const int MINIMUM_PLAYER_COUNT = 2;
	static const int MAXIMUM_PLAYER_COUNT = 10;

	// Limite para el volumen del tablero
	static const int MINIMUM_BOARD_ROW_COUNT = 6;
	static const int MAXIMUM_BOARD_ROW_COUNT = 50;
	static const int MINIMUM_BOARD_COLUMN_COUNT = 6;
	static const int MAXIMUM_BOARD_COLUMN_COUNT = 50;
	static const int MINIMUM_BOARD_LEVEL_COUNT = 6;
	static const int MAXIMUM_BOARD_LEVEL_COUNT = 50;

private:
	// Limite para la cantidad de soldados
	static const int FEW_PLAYER_MINIMUM_SOLDIER_COUNT = 8;
	static const int FEW_PLAYER_MAXIMUM_SOLDIER_COUNT = 100;
	static const int MANY_PLAYER_MINIMUM_SOLDIER_COUNT = 20;
	static const int MANY_PLAYER_MAXIMUM_SOLDIER_COUNT = 100;

	// Porcentaje de armamentos en función de la cantidad
	// de soldados que tiene el jugadors
	static const int PLAYER_AIRCRAFT_COUNT_DENSITY_PERCENT = 20;
	static const int PLAYER_WARSHIP_COUNT_DENSITY_PERCENT = 20;

public:
	/*
	 * PRE: Los argumentos deben estar dentro del rango valido.
	 *		playerCount: [MINIMUM_PLAYER_COUNT; MAXIMUM_PLAYER_COUNT]
	 *		boardRowCount: [MINIMUM_BOARD_ROW_COUNT; MAXIMUM_BOARD_ROW_COUNT]
	 *		boardColumnCount: [MINIMUM_BOARD_COLUMN_COUNT; MAXIMUM_BOARD_COLUMN_COUNT]
	 *		boardLevelCount: [MINIMUM_BOARD_LEVEL_COUNT; MAXIMUM_BOARD_LEVEL_COUNT]
	 * POS: Crea una nueva instancia de GameConfig.
	 */
	GameConfig(int playerCount, int boardRowCount, int boardColumnCount, int boardLevelCount);
	/*
	 * PRE: -
	 * POS: Destruye la instancia del GameConfig.
	 */
	virtual ~GameConfig();
	/*
	 * PRE: -
	 * POS: Devuelve la cantidad de jugadores.
	 */
	int getCommanderCount() const;
	/*
	 * PRE: -
	 * POS: Devuelve la cantidad de niveles que tiene el tablero del juego.
	 */
	int getBoardLevelCount() const;
	/*
	 * PRE: -
	 * POS: Devuelve la cantidad de filas que tiene cada nivel del tablero del juego.
	 */
	int getBoardRowCount() const;
	/*
	 * PRE: -
	 * POS: Devuelve la cantidad de columnas que tiene cada nivel del tablero del juego.
	 */
	int getBoardColumnCount() const;
	/*
	 * PRE: -
	 * POS: Devuelve la cantidad total de soldador iniciales del juego.
	 */
	int getTotalSoldierCount() const;
	/*
	 * PRE: -
	 * POS: Devuelve la cantidad de soldados iniciales que tiene cada jugador.
	 */
	int getCommanderSoldiersCount() const;
	/*
	 * PRE: -
	 * POS: Devuelve la cantidad de aviones iniciales que tiene cada jugador.
	 */
	int getCommanderAircraftCount() const;
	/*
	 * PRE: -
	 * POS: Devuelve la cantidad de barcos iniciales que tiene cada jugador.
	 */
	int getCommanderWarshipsCount() const;
};

#endif /* BOARD_GAME_GAME_CONFIG_GAME_CONFIG_H_ */
