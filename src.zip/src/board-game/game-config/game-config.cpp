/*
 * game-config.cpp
 *
 */

#include "game-config.h"

GameConfig::GameConfig(int commanderCount, int boardRowCount, int boardColumnCount, int boardLevelCount)
{
	this->commanderCount = commanderCount;
	this->boardRowCount = boardRowCount;
	this->boardColumnCount = boardColumnCount;
	this->boardLevelCount = boardLevelCount;
}

GameConfig::~GameConfig()
{
}

int GameConfig::getCommanderCount() const
{
	return this->commanderCount;
}

int GameConfig::getBoardLevelCount() const
{
	return this->boardLevelCount;
}

int GameConfig::getBoardRowCount() const
{
	return this->boardRowCount;
}

int GameConfig::getBoardColumnCount() const
{
	return this->boardColumnCount;
}

int GameConfig::getTotalSoldierCount() const
{
	// Limites para jugadores
	int nm = MINIMUM_PLAYER_COUNT;
	int nM = MAXIMUM_PLAYER_COUNT;

	// Límite volumen tablero
	int vm = MINIMUM_BOARD_ROW_COUNT * MINIMUM_BOARD_COLUMN_COUNT * MINIMUM_BOARD_LEVEL_COUNT;
	int vM = MAXIMUM_BOARD_ROW_COUNT * MAXIMUM_BOARD_COLUMN_COUNT * MAXIMUM_BOARD_LEVEL_COUNT;

	// Pendiente de rectas límite
	double m1 = 1.0 * (FEW_PLAYER_MAXIMUM_SOLDIER_COUNT - FEW_PLAYER_MINIMUM_SOLDIER_COUNT) / (vM - vm);
	double m2 = 1.0 * (MANY_PLAYER_MAXIMUM_SOLDIER_COUNT - MANY_PLAYER_MINIMUM_SOLDIER_COUNT) / (vM - vm);

	// Volumen del tablero
	int v = this->boardColumnCount * this->boardRowCount * this->boardLevelCount;
	// Cantidad de jugadores
	int n = this->commanderCount;

	double s1 = m1 * (v - vm) + FEW_PLAYER_MINIMUM_SOLDIER_COUNT;
	double s2 = m2 * (v - vm) + MANY_PLAYER_MINIMUM_SOLDIER_COUNT;

	// Parametros de funciones racionales
	double a = 1.0 * nm * nM / (nM - nm) * (s1 - s2);
	double b = (1 - 1.0 * nM / (nM - nm)) * s1 + 1.0 * nM / (nM - nm) * s2;

	return a / n + b;
}

int GameConfig::getCommanderSoldiersCount() const
{
	return getTotalSoldierCount() / commanderCount;
}

int GameConfig::getCommanderAircraftCount() const
{
	int aircraftsPerPlayerCount = this->getCommanderSoldiersCount() * PLAYER_AIRCRAFT_COUNT_DENSITY_PERCENT / 100.0;
	return aircraftsPerPlayerCount > 0 ? aircraftsPerPlayerCount : 1;
}

int GameConfig::getCommanderWarshipsCount() const
{
	int warshipsPerPlayerCount = this->getCommanderSoldiersCount() * PLAYER_WARSHIP_COUNT_DENSITY_PERCENT / 100.0;
	return warshipsPerPlayerCount > 0 ? warshipsPerPlayerCount : 1;
}
